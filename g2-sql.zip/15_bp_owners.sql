-- 15_bp_owners.sql — у кого уже есть премиум батлпасс (для блокировки подарка в клиенте)
-- Выполнить целиком в Supabase → SQL Editor (можно повторно).
-- Возвращает ники игроков, у которых премиум текущего сезона уже активен
-- ИЛИ ему уже отправлен непринятый подарок премиума (300 тикетов за 1 монету).

create or replace function public.g2_bp_owners(p_token text, p_season text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
begin
  me := public.g2_auth(p_token);
  return coalesce((
    select jsonb_agg(p.nick)
      from public.g2_players p
     where not p.banned
       and (
            (coalesce(p.save->'bp'->>'pr', '0') in ('1', 'true')
             and coalesce(p.save->'bp'->>'s', '') = coalesce(p_season, ''))
            or exists (select 1 from public.g2_tr_offers o
                        where o.to_uid = p.uid and o.status = 'pending'
                          and o.give = '{"$gems":300}'::jsonb
                          and o.want = '{"$coins":1}'::jsonb)
       )
  ), '[]'::jsonb);
end;
$fn$;

revoke all on function public.g2_bp_owners(text, text) from public, anon, authenticated;
grant execute on function public.g2_bp_owners(text, text) to anon, authenticated;
