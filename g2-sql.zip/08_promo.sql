-- ============================================================================
-- 08 · ПРОМОКОДЫ (после 07)
-- Создавать и удалять коды могут владелец и админы (панель «Промокод» в меню).
-- Один аккаунт активирует один и тот же код только один раз.
-- ============================================================================

-- активировать код (любой вошедший игрок); награду сайт начисляет сам
create or replace function public.g2_promo_redeem(p_token text, p_code text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; p public.g2_promos; c text := upper(trim(coalesce(p_code, '')));
begin
  r := public.g2_auth(p_token);
  select * into p from public.g2_promos where code = c for update;
  if not found then
    perform pg_sleep(0.4);                                  -- замедляем перебор кодов
    raise exception 'Промокод не найден';
  end if;
  if p.expires_at is not null and p.expires_at <= now() then raise exception 'Срок промокода истёк'; end if;
  if p.max_uses is not null and p.uses >= p.max_uses then raise exception 'Промокод закончился'; end if;
  if exists (select 1 from public.g2_promo_uses where code = c and uid = r.uid) then
    raise exception 'Вы уже использовали этот промокод';
  end if;
  insert into public.g2_promo_uses(code, uid) values (c, r.uid);
  update public.g2_promos set uses = uses + 1 where code = c;
  return jsonb_build_object('coins', p.coins, 'gems', p.gems);
end $fn$;

create or replace function public.g2_promo_create(p_token text, p_code text, p_coins numeric, p_gems numeric,
                                                     p_max_uses int, p_hours numeric) returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; c text := upper(trim(coalesce(p_code, '')));
        co numeric := floor(coalesce(p_coins, 0)); ge numeric := floor(coalesce(p_gems, 0));
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  if c !~ '^[A-Z0-9_-]{3,24}$' then raise exception 'Код: 3–24 символа — латиница, цифры, _ и -'; end if;
  if co < 0 or ge < 0 or (co = 0 and ge = 0) or co > 9000000000000000 or ge > 9000000000000000 then
    raise exception 'Некорректная награда';
  end if;
  if p_max_uses is not null and p_max_uses < 1 then raise exception 'Некорректный лимит активаций'; end if;
  if p_hours is not null and p_hours <= 0 then raise exception 'Некорректный срок'; end if;
  if exists (select 1 from public.g2_promos where code = c) then raise exception 'Такой промокод уже есть'; end if;
  insert into public.g2_promos(code, coins, gems, max_uses, expires_at, created_by)
  values (c, co, ge, p_max_uses,
          case when p_hours is null then null else now() + make_interval(secs => (p_hours * 3600)::double precision) end,
          r.nick);
  insert into public.g2_mod_log(actor, target, action, detail)
  values (r.nick, c, 'promo_create',
          'монеты ' || co || ', тикеты ' || ge || ', активаций ' || coalesce(p_max_uses::text, '∞')
          || ', срок ' || coalesce(p_hours::text || ' ч', 'без срока'));
end $fn$;

create or replace function public.g2_promo_list(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('code', code, 'coins', coins, 'gems', gems,
                                                       'uses', uses, 'max_uses', max_uses, 'expires_at', expires_at)
                                    order by created_at desc)
                     from public.g2_promos), '[]'::jsonb);
end $fn$;

create or replace function public.g2_promo_delete(p_token text, p_code text) returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  delete from public.g2_promos where code = upper(trim(coalesce(p_code, '')));
  if found then
    insert into public.g2_mod_log(actor, target, action) values (r.nick, upper(trim(coalesce(p_code, ''))), 'promo_delete');
  end if;
end $fn$;
