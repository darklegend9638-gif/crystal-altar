-- 14_pass_owners.sql — кто уже владеет пассом (для блокировки подарка в клиенте)
-- Выполнить целиком в Supabase → SQL Editor (можно повторно).
-- Возвращает ники игроков, у которых пасс уже есть ИЛИ подарок на него ещё не забран.

create or replace function public.g2_pass_owners(p_token text, p_pass text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
begin
  me := public.g2_auth(p_token);
  return coalesce((
    select jsonb_agg(p.nick)
      from public.g2_players p
     where not p.banned
       and (coalesce(p.save->'gp'->>p_pass, '0') in ('1', 'true')
            or exists (select 1 from public.g2_gifts g
                        where g.to_key = p.key and g.pass = p_pass and g.claimed_at is null))
  ), '[]'::jsonb);
end;
$fn$;

revoke all on function public.g2_pass_owners(text, text) from public, anon, authenticated;
grant execute on function public.g2_pass_owners(text, text) to anon, authenticated;
