-- ============================================================================
-- 11 · ТРЕЙДЫ ТОЛЬКО ДЛЯ АККАУНТОВ СТАРШЕ 7 ДНЕЙ (после 10)
-- Проверяется возраст ОБОИХ аккаунтов (g2_players.created_at):
--   · при открытии партнёра и отправке предложения (g2_trade_partner / g2_trade_send)
--   · при принятии предложения (g2_trade_respond) — на случай, если аккаунт младше 7 дней
--     получил предложение раньше. Отклонить/отменить можно всегда.
-- Коды ошибок trade_self_too_young / trade_partner_too_young сайт показывает понятным текстом.
-- ИСКЛЮЧЕНИЕ: подарок премиума другу (отдаёшь ровно 300 💎, просишь 1 🪙) можно отправлять и принимать
-- без ожидания 7 дней — для него проверка возраста аккаунтов пропускается.
-- Чтобы изменить срок — замените '7 days' во всех функциях ниже.
-- Безопасно запускать повторно.
-- ============================================================================

-- подарок премиума: отдаём только 300 💎, просим только 1 🪙 (так сайт шлёт подарок)
create or replace function public.g2_tr_gift(g jsonb, w jsonb) returns boolean
language sql immutable as $fn$
  select g is not null and w is not null
     and jsonb_typeof(g) = 'object' and jsonb_typeof(w) = 'object'
     and (select count(*) from jsonb_object_keys(g)) = 1
     and (select count(*) from jsonb_object_keys(w)) = 1
     and g ? '$gems' and w ? '$coins'
     and (g->>'$gems')::numeric = 300 and (w->>'$coins')::numeric = 1
$fn$;

create or replace function public.g2_trade_partner(p_token text, p_nick text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; t public.g2_players; inv jsonb; d jsonb := '{}'::jsonb; e record; q numeric;
begin
  r := public.g2_auth(p_token);
  if r.created_at > now() - interval '7 days' then raise exception 'trade_self_too_young'; end if;
  select * into t from public.g2_players where key = lower(trim(coalesce(p_nick, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if t.uid = r.uid then raise exception 'Нельзя меняться с собой'; end if;
  if t.created_at > now() - interval '7 days' then raise exception 'trade_partner_too_young'; end if;
  inv := public.g2_tr_inv(t.save, public.g2_tr_ia(t.uid));
  for e in select key, value from jsonb_each(inv) loop
    q := (e.value #>> '{}')::numeric;
    if e.key not like '$%' and q > 1 then d := d || jsonb_build_object(e.key, q - 1); end if;
  end loop;
  return jsonb_build_object('dupes', d,
    'coins', greatest(0, public.g2_tr_num(inv, '$coins')),
    'gems',  greatest(0, public.g2_tr_num(inv, '$gems')));
end $fn$;

create or replace function public.g2_trade_send(p_token text, p_to text, p_give jsonb, p_want jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; t public.g2_players; g jsonb; w jsonb; cnt int; ep int; oid bigint; gift boolean;
begin
  perform pg_advisory_xact_lock(7003);
  r := public.g2_auth(p_token);
  g := public.g2_tr_clean(p_give);
  w := public.g2_tr_clean(p_want);
  gift := public.g2_tr_gift(g, w);
  if not gift and r.created_at > now() - interval '7 days' then raise exception 'trade_self_too_young'; end if;
  select * into t from public.g2_players where key = lower(trim(coalesce(p_to, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if t.uid = r.uid then raise exception 'Нельзя меняться с собой'; end if;
  if not gift and t.created_at > now() - interval '7 days' then raise exception 'trade_partner_too_young'; end if;
  if not public.g2_tr_has(public.g2_tr_inv(r.save, public.g2_tr_ia(r.uid)), g) then
    raise exception 'У вас нет столько предметов или денег';
  end if;
  if not public.g2_tr_has(public.g2_tr_inv(t.save, public.g2_tr_ia(t.uid)), w) then
    raise exception 'У игрока нет столько предметов или денег';
  end if;
  perform public.g2_tr_gc();
  select count(*) into cnt from public.g2_tr_offers where from_uid = r.uid and status = 'pending';
  if cnt >= 10 then raise exception 'Слишком много активных предложений (макс. 10)'; end if;
  select epoch into ep from public.g2_meta where id = 1;
  insert into public.g2_tr_offers(from_uid, to_uid, give, want, epoch)
  values (r.uid, t.uid, g, w, ep) returning id into oid;
  return jsonb_build_object('id', oid);
end $fn$;

create or replace function public.g2_trade_respond(p_token text, p_id bigint, p_accept boolean) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; p public.g2_players; o public.g2_tr_offers;
        invp jsonb; invq jsonb; ia_q jsonb;
begin
  perform pg_advisory_xact_lock(7003);
  r := public.g2_auth(p_token);
  perform public.g2_tr_gc();
  select * into o from public.g2_tr_offers where id = p_id for update;
  if not found or o.status <> 'pending' then raise exception 'Предложение уже не активно'; end if;

  if r.uid = o.from_uid then                       -- отправитель может только отменить
    if coalesce(p_accept, false) then raise exception 'Нет доступа'; end if;
    update public.g2_tr_offers set status = 'cancelled', done_at = now() where id = o.id;
    return jsonb_build_object('ok', true);
  elsif r.uid <> o.to_uid then
    raise exception 'Нет доступа';
  end if;

  if not coalesce(p_accept, false) then            -- получатель отказывается
    update public.g2_tr_offers set status = 'declined', done_at = now() where id = o.id;
    return jsonb_build_object('ok', true);
  end if;

  select * into p from public.g2_players where uid = o.from_uid;
  if not found or p.banned then raise exception 'Отправитель недоступен'; end if;
  if not public.g2_tr_gift(o.give, o.want) then   -- подарок премиума возрастом аккаунтов не ограничен
    if r.created_at > now() - interval '7 days' then raise exception 'trade_self_too_young'; end if;
    if p.created_at > now() - interval '7 days' then raise exception 'trade_partner_too_young'; end if;
  end if;
  invp := public.g2_tr_inv(p.save, public.g2_tr_ia(p.uid));
  invq := public.g2_tr_inv(r.save, public.g2_tr_ia(r.uid));
  if not public.g2_tr_has(invp, o.give) then
    raise exception 'У отправителя уже нет нужных предметов или денег';
  end if;
  if not public.g2_tr_has(invq, o.want) then
    raise exception 'У вас нет нужных предметов или денег';
  end if;

  -- отправитель: −give +want, получатель: +give −want
  update public.g2_tr_adj
     set ia = public.g2_tr_add(ia, public.g2_tr_add(public.g2_tr_neg(o.give), o.want))
   where uid = p.uid;
  update public.g2_tr_adj
     set ia = public.g2_tr_add(ia, public.g2_tr_add(o.give, public.g2_tr_neg(o.want)))
   where uid = r.uid returning ia into ia_q;
  update public.g2_tr_offers set status = 'done', done_at = now() where id = o.id;
  return jsonb_build_object('iadj', ia_q);
end $fn$;
