-- ============================================================================
-- 06 · АДМИНКА И МОДЕРАЦИЯ (после 05)
-- Админ-правки и очистка поднимают версию (устаревшие вкладки игрока их не перезапишут),
-- сброс всем обнуляет и висящие входящие монеты. Бан убирает игрока из клана и отменяет его трейды.
-- ============================================================================

-- журнал действий: подробности (что выдали/забрали). Для баз, созданных до этой версии
alter table public.g2_mod_log add column if not exists detail text;

-- человекочитаемая разница двух сохранений: монеты/тикеты со знаком, остальное «было→стало»
create or replace function public.g2_diff_save(o jsonb, n jsonb) returns text
language plpgsql immutable as $fn$
declare k text; parts text[] := '{}'; a numeric; b numeric; ca int; cb int; t1 text; t2 text; lbl text;
begin
  o := coalesce(o, '{}'::jsonb); n := coalesce(n, '{}'::jsonb);
  for k in select x from (select jsonb_object_keys(o) as x union select jsonb_object_keys(n)) q order by x loop
    if k in ('_v', 'ver') or (o -> k) is not distinct from (n -> k) then continue; end if;
    t1 := jsonb_typeof(o -> k); t2 := jsonb_typeof(n -> k);
    lbl := case k when 'coins' then 'монеты' when 'gem' then 'тикеты' when 'luck' then 'удача' when 'inc' then 'доход'
                  when 'rolls' then 'роллы' when 'found' then 'коллекция' when 'pt' then 'питомцы' when 'tb' then 'титулы'
                  else k end;
    if coalesce(t1, 'number') = 'number' and coalesce(t2, 'number') = 'number' then
      a := coalesce((o ->> k)::numeric, 0); b := coalesce((n ->> k)::numeric, 0);
      if a = b then continue; end if;
      if k in ('coins', 'gem') then
        parts := parts || (lbl || ' ' || case when b > a then '+' else '−' end || trim(to_char(abs(b - a), 'FM999999999999999990'))
                       || ' (' || trim(to_char(a, 'FM999999999999999990')) || '→' || trim(to_char(b, 'FM999999999999999990')) || ')');
      else
        parts := parts || (lbl || ' ' || trim(to_char(a, 'FM999999999999999990')) || '→' || trim(to_char(b, 'FM999999999999999990')));
      end if;
    elsif coalesce(t1, t2) in ('array', 'object') then
      ca := case coalesce(t1, 'null') when 'array' then jsonb_array_length(o -> k) when 'object' then (select count(*) from jsonb_object_keys(o -> k)) else 0 end;
      cb := case coalesce(t2, 'null') when 'array' then jsonb_array_length(n -> k) when 'object' then (select count(*) from jsonb_object_keys(n -> k)) else 0 end;
      if ca <> cb then parts := parts || (lbl || ' ' || ca || '→' || cb);
      elsif ca > 0 then parts := parts || (lbl || ' изменено'); end if;
    else
      parts := parts || (lbl || ' изменено');
    end if;
  end loop;
  return left(array_to_string(parts, '; '), 400);
end $fn$;

create or replace function public.g2_admin_get(p_token text, p_key text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; s jsonb;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  -- владелец видит всех, кроме владельцев; админ — только обычных игроков (не владельца, не админов, не себя)
  select save into s from public.g2_players
   where key = p_key and role <> 'owner' and key <> r.key and (r.role = 'owner' or role = '');
  if not found then raise exception 'Игрок не найден'; end if;
  return coalesce(s, '{}'::jsonb);
end $fn$;

create or replace function public.g2_admin_set(p_token text, p_key text, p_save jsonb) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t_nick text; old_s jsonb;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  if not public.g2_save_ok(p_save) then raise exception 'Некорректное сохранение'; end if;
  select save into old_s from public.g2_players
   where key = p_key and role <> 'owner' and key <> r.key and (r.role = 'owner' or role = '') for update;
  update public.g2_players set save = p_save - '_v', epoch = -1, ver = ver + 1
   where key = p_key and role <> 'owner' and key <> r.key and (r.role = 'owner' or role = '')
   returning nick into t_nick;
  if not found then raise exception 'Игрок не найден'; end if;
  insert into public.g2_mod_log(actor, target, action, detail)
  values (r.nick, t_nick, 'edit', coalesce(nullif(public.g2_diff_save(old_s, p_save - '_v'), ''), 'без изменений'));
  return jsonb_build_object('ok', true);
end $fn$;

-- очистка профиля; владелец может очистить и СЕБЯ
create or replace function public.g2_clear_profile(p_token text, p_key text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t_nick text; old_s jsonb;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет доступа'; end if;
  select save into old_s from public.g2_players where key = p_key and (role <> 'owner' or key = r.key) for update;
  update public.g2_players
     set save = public.g2_fresh(), avatar = '😀', epoch = -1, ver = ver + 1, inbox = 0, inbox_from = ''
   where key = p_key and (role <> 'owner' or key = r.key)
   returning nick into t_nick;
  if not found then raise exception 'Игрок не найден'; end if;
  insert into public.g2_mod_log(actor, target, action, detail)
  values (r.nick, t_nick, 'clear', 'стёрто: ' || public.g2_diff_save(old_s, public.g2_fresh()));
  return jsonb_build_object('ok', true);
end $fn$;

-- сброс прогресса всем: заодно обнуляет непринятые входящие монеты, чтобы они не вернули деньги после сброса
create or replace function public.g2_reset_all(p_token text) returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; ep int;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет прав'; end if;
  update public.g2_meta set epoch = epoch + 1 where id = 1 returning epoch into ep;
  update public.g2_players set save = public.g2_fresh(), ver = ver + 1, inbox = 0, inbox_from = '' where true;
  update public.g2_players set epoch = ep where key = r.key;
  insert into public.g2_mod_log(actor, target, action) values (r.nick, '*', 'reset_all');
end $fn$;

create or replace function public.g2_ban(p_token text, p_key text, p_ban boolean, p_reason text default '')
returns jsonb language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t public.g2_players; why text := left(coalesce(p_reason, ''), 60);
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  select * into t from public.g2_players where key = p_key;
  if not found then raise exception 'Игрок не найден'; end if;
  if t.key = r.key or t.role = 'owner' or (t.role = 'admin' and r.role <> 'owner') then
    raise exception 'Нельзя заблокировать этого игрока';
  end if;

  if p_ban then
    update public.g2_players set
           pass_bak   = case when banned then pass_bak else pass_hash end,
           pass_hash  = '!banned',
           banned     = true,
           token      = public.g2_new_token(),             -- новый случайный токен: старые сессии перестают работать
           ban_reason = why
     where key = p_key;
    perform public._g2clan_leave(t.uid);                    -- глава передаётся следующему по рангу
    update public.g2_tr_offers set status = 'cancelled', done_at = now()
     where status = 'pending' and (from_uid = t.uid or to_uid = t.uid);
    insert into public.g2_mod_log(actor, target, action, reason) values (r.nick, t.nick, 'ban', why);
  else
    update public.g2_players set
           pass_hash  = coalesce(pass_bak, pass_hash),
           pass_bak   = null,
           banned     = false,
           ban_reason = null
     where key = p_key and banned;
    insert into public.g2_mod_log(actor, target, action) values (r.nick, t.nick, 'unban');
  end if;
  return jsonb_build_object('ok', true);
end $fn$;

create or replace function public.g2_set_role(p_token text, p_key text, p_role text) returns void
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t_nick text;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет прав'; end if;
  if p_role not in ('', 'admin') then raise exception 'Неверная роль'; end if;
  update public.g2_players set role = p_role where key = p_key and role <> 'owner' returning nick into t_nick;
  if found then
    insert into public.g2_mod_log(actor, target, action)
    values (r.nick, t_nick, case when p_role = 'admin' then 'make_admin' else 'remove_admin' end);
  end if;
end $fn$;

create or replace function public.g2_mod_list(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('key', key, 'nick', nick, 'role', role, 'banned', banned,
                                        'avatar', avatar, 'reason', coalesce(ban_reason, ''))
                     order by nick)
      from public.g2_players where key <> r.key and role <> 'owner'), '[]'::jsonb);
end $fn$;

create or replace function public.g2_mod_log_list(p_token text, p_limit integer default 50) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет доступа'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('at', l.ts, 'actor', l.actor, 'target', l.target,
                                        'action', l.action, 'reason', coalesce(l.reason, ''),
                                        'detail', coalesce(l.detail, ''))
                     order by l.ts desc)
      from (select * from public.g2_mod_log order by ts desc
             limit least(greatest(coalesce(p_limit, 50), 1), 300)) l), '[]'::jsonb);
end $fn$;

-- список всех игроков (для владельца)
create or replace function public.g2_players(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет прав'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('key', key, 'nick', nick, 'avatar', avatar, 'role', role)
                                    order by created_at)
                     from public.g2_players), '[]'::jsonb);
end $fn$;

-- запись в журнал о правке СЕБЯ (на своём профиле админка работает локально — сайт присылает итог сюда)
create or replace function public.g2_admin_log(p_token text, p_detail text) returns void
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; d text := left(btrim(coalesce(p_detail, '')), 400);
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  if d = '' then return; end if;
  insert into public.g2_mod_log(actor, target, action, detail) values (r.nick, r.nick, 'self_edit', d);
end $fn$;
