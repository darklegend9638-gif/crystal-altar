-- ============================================================================
-- 07 · ИВЕНТЫ (после 06)
-- Автоивент: в начале каждого часа на auto_len минут включается событие, выбранное по весам.
-- Выбор детерминирован по номеру часа, поэтому у всех игроков он одинаковый.
-- Сезонные (Валентин, Хэллоуин…) в автовыбор не входят — запускаются вручную из админки.
-- ============================================================================

-- веса автоивентов: чем больше число — тем чаще. Мощные редкие, слабые частые.
insert into public.g2_event_cfg(ev, weight, tier) values
  ('shop', 16, 'common'), ('sale', 16, 'common'), ('pity', 14, 'common'),
  ('luck2', 12, 'common'), ('gold', 10, 'common'), ('gain', 10, 'common'),
  ('storm', 8, 'uncommon'), ('rare', 6, 'uncommon'),
  ('bless', 5, 'rare'), ('mega', 1.5, 'epic')
on conflict (ev) do update set weight = excluded.weight, tier = excluded.tier;

-- какой ивент выпал в данном часе (salt позволяет перебросить, если выпал тот же, что в прошлом часу)
create or replace function public.g2_auto_pick(slot bigint, salt integer) returns text
language plpgsql stable set search_path = public as $fn$
declare tot numeric; x numeric; acc numeric := 0; rec record; last_ev text;
begin
  select coalesce(sum(weight), 0) into tot from public.g2_event_cfg where weight > 0;
  if tot <= 0 then return null; end if;
  x := (('x' || substr(md5('ev' || slot::text || ':' || salt::text), 1, 7))::bit(28)::int / 268435456.0) * tot;
  for rec in select ev, weight from public.g2_event_cfg where weight > 0 order by ev loop
    acc := acc + rec.weight;
    last_ev := rec.ev;
    if x < acc then return rec.ev; end if;
  end loop;
  return last_ev;
end $fn$;

-- итог часа: один и тот же ивент два часа подряд не выпадает
create or replace function public.g2_auto_ev(slot bigint) returns text
language plpgsql stable set search_path = public as $fn$
declare prev text; cur text; s int;
begin
  prev := public.g2_auto_pick(slot - 1, 0);
  for s in 0..5 loop
    cur := public.g2_auto_pick(slot, s);
    if cur is distinct from prev then return cur; end if;
  end loop;
  return cur;
end $fn$;

-- текущие ивенты: ручные + автоматический
create or replace function public.g2_event_get() returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare
  r public.g2_event; slot bigint; s_start timestamptz; s_end timestamptz; nxt timestamptz;
  lst jsonb; aev text;
begin
  select * into r from public.g2_event where id = 1;
  delete from public.g2_event_live where until <= now();

  select coalesce(jsonb_agg(jsonb_build_object('ev', ev, 'left', floor(extract(epoch from (until - now()))), 'auto', false)
                            order by until), '[]'::jsonb)
    into lst from public.g2_event_live;

  slot    := floor(extract(epoch from now()) / 3600)::bigint;
  s_start := to_timestamp(slot * 3600);
  s_end   := s_start + make_interval(mins => least(greatest(r.auto_len, 1), 59));
  nxt     := s_start + interval '1 hour';

  if r.auto_on and now() < s_end then
    aev := public.g2_auto_ev(slot);
    if aev is not null and not exists (select 1 from public.g2_event_live where ev = aev) then
      lst := lst || jsonb_build_array(jsonb_build_object('ev', aev, 'left', floor(extract(epoch from (s_end - now()))), 'auto', true));
    end if;
  end if;

  return jsonb_build_object(
    'list', lst,
    'ev', coalesce(lst->0->>'ev', ''),
    'left', coalesce((lst->0->>'left')::numeric, 0),
    'auto_on', r.auto_on,
    'next', case when r.auto_on then ceil(extract(epoch from (nxt - now()))) else 0 end);
end $fn$;

-- запустить ивент на N минут. Пустое имя или N < 1 — остановить все ручные ивенты
create or replace function public.g2_event_set(p_token text, p_ev text, p_minutes integer) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  if p_ev is null or p_ev = '' or p_minutes is null or p_minutes < 1 then
    delete from public.g2_event_live where true;
    insert into public.g2_mod_log(actor, target, action, detail) values (r.nick, '*', 'event_stop', 'остановлены все ручные ивенты');
  else
    if p_ev not in ('luck2', 'bless', 'gold', 'storm', 'sale', 'shop', 'pity', 'gain', 'rare', 'mega',
                    'winter', 'newyear', 'valentine', 'spring', 'summer', 'autumn', 'halloween') then
      raise exception 'Неизвестный ивент';
    end if;
    insert into public.g2_event_live(ev, until)
    values (p_ev, now() + make_interval(mins => least(p_minutes, 43200)))
    on conflict (ev) do update set until = excluded.until;
    insert into public.g2_mod_log(actor, target, action, detail)
    values (r.nick, p_ev, 'event_start', 'на ' || least(p_minutes, 43200) || ' мин');
  end if;
  return jsonb_build_object('ok', true);
end $fn$;

create or replace function public.g2_event_stop(p_token text, p_ev text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  delete from public.g2_event_live where ev = p_ev;
  insert into public.g2_mod_log(actor, target, action, detail) values (r.nick, coalesce(p_ev, '*'), 'event_stop', 'ивент остановлен');
  return jsonb_build_object('ok', true);
end $fn$;

create or replace function public.g2_event_auto(p_token text, p_on boolean) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  update public.g2_event set auto_on = coalesce(p_on, true) where id = 1;
  insert into public.g2_mod_log(actor, target, action, detail)
  values (r.nick, '*', 'event_auto', case when coalesce(p_on, true) then 'авто-ивенты включены' else 'авто-ивенты выключены' end);
  return jsonb_build_object('ok', true);
end $fn$;
