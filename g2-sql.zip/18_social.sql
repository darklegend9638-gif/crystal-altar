-- ============================================================================
-- 18 · СОЦИАЛКА: ПРЕМИУМ БАТЛПАССА В ПОДАРОК НАПРЯМУЮ, ДРУЗЬЯ, ИКОНКА ПРИ ОЧИСТКЕ
-- (выполнять после 06_gifts.sql, 06_admin.sql, 14, 15, 16, 17)
--  · g2_gift_bp       — подарить премиум батлпасса (300 💎): выдаётся САМ, как другие пассы
--                        (получатель забирает через g2_gift_claim, принимать трейд не нужно)
--  · g2_gift_claim    — теперь понимает пасс 'bp' и включает премиум в сохранении
--  · g2_bp_owners     — учитывает и неполученные подарки премиума
--  · g2_clear_profile — очистка профиля НЕ сбрасывает иконку (avatar остаётся)
--  · друзья: таблица g2_friends + g2_friend_add / respond / remove / list
-- Безопасно запускать повторно.
-- ============================================================================

create or replace function public.g2_clear_profile(p_token text, p_key text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t_nick text; old_s jsonb;
begin
  r := public.g2_auth(p_token);
  if r.role <> 'owner' then raise exception 'Нет доступа'; end if;
  select save into old_s from public.g2_players where key = p_key and (role <> 'owner' or key = r.key) for update;
  update public.g2_players
     set save = public.g2_fresh(), epoch = -1, ver = ver + 1, inbox = 0, inbox_from = ''
   where key = p_key and (role <> 'owner' or key = r.key)
   returning nick into t_nick;
  if not found then raise exception 'Игрок не найден'; end if;
  insert into public.g2_mod_log(actor, target, action, detail)
  values (r.nick, t_nick, 'clear', 'стёрто: ' || public.g2_diff_save(old_s, public.g2_fresh()));
  return jsonb_build_object('ok', true);
end $fn$;

create or replace function public.g2_gift_claim(p_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me     public.g2_players;
  r      record;
  v_list jsonb := '[]'::jsonb;
  v_ver  bigint;
begin
  me := public.g2_auth(p_token);
  select * into me from public.g2_players where key = me.key for update;
  v_ver := me.ver;

  for r in
    select g.id, g.pass,
           (select u.nick from public.g2_players u where u.key = g.from_key) as from_nick
      from public.g2_gifts g
     where g.to_key = me.key and g.claimed_at is null
     order by g.id
       for update of g
  loop
    update public.g2_gifts set claimed_at = now() where id = r.id;

    if r.pass = 'bp' then
      -- премиум батлпасса: выдаётся сразу, без трейда
      update public.g2_players
         set save = jsonb_set(
               save, '{bp}',
               case when jsonb_typeof(save->'bp') = 'object'
                         and coalesce(save->'bp'->>'s', '') >= to_char(now(), 'YYYY-MM')
                    then (save->'bp') || '{"pr":1}'::jsonb
                    else jsonb_build_object('s', to_char(now(), 'YYYY-MM'), 'xp', 0, 'pr', 1, 'c', 0, 'p', 0) end)
       where key = me.key;
    else
      update public.g2_players
         set save = jsonb_set(
               case when jsonb_typeof(save->'gp') = 'object' then save
                    else jsonb_set(save, '{gp}', '{}'::jsonb) end,
               array['gp', r.pass], '1'::jsonb)
       where key = me.key;
    end if;

    v_list := v_list || jsonb_build_object('pass', r.pass, 'from', r.from_nick);
  end loop;

  if jsonb_array_length(v_list) > 0 then
    update public.g2_players set ver = ver + 1 where key = me.key returning ver into v_ver;
  end if;

  return jsonb_build_object('gifts', v_list, 'v', v_ver);
end;
$fn$;

-- подарок премиума батлпасса напрямую (без трейда)
create or replace function public.g2_gift_bp(p_token text, p_to text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me      public.g2_players;
  tg      public.g2_players;
  v_price constant numeric := 300;
  v_gem   numeric;
  v_new   numeric;
  v_ver   bigint;
  v_seas  text := to_char(now(), 'YYYY-MM');
begin
  me := public.g2_auth(p_token);
  select * into me from public.g2_players where key = me.key for update;

  select * into tg from public.g2_players
   where key = lower(btrim(coalesce(p_to, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if tg.key = me.key then raise exception 'Нельзя дарить себе'; end if;

  if (coalesce(tg.save->'bp'->>'pr', '0') in ('1', 'true')
      and coalesce(tg.save->'bp'->>'s', '') >= v_seas)
     or exists (select 1 from public.g2_gifts
                 where to_key = tg.key and pass = 'bp' and claimed_at is null) then
    raise exception 'У игрока уже есть премиум батлпасс';
  end if;

  if (select count(*) from public.g2_gifts
       where from_key = me.key and pass = 'bp' and created_at > now() - interval '1 hour') >= 20 then
    raise exception 'Слишком много подарков за час, попробуйте позже';
  end if;

  v_gem := case when jsonb_typeof(me.save->'gem') = 'number' then (me.save->>'gem')::numeric else 0 end;
  if v_gem < v_price then raise exception 'Не хватает тикетов'; end if;
  v_new := floor(v_gem - v_price);

  update public.g2_players
     set save = jsonb_set(save, '{gem}', to_jsonb(v_new)), ver = ver + 1
   where key = me.key
   returning ver into v_ver;

  insert into public.g2_gifts (from_key, to_key, pass, price)
  values (me.key, tg.key, 'bp', v_price);

  return jsonb_build_object('ok', true, 'gem', v_new, 'v', v_ver);
end;
$fn$;

-- кто уже владеет премиумом батлпасса (теперь учитываются и подарки из g2_gifts)
create or replace function public.g2_bp_owners(p_token text, p_season text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
begin
  me := public.g2_auth(p_token);
  return coalesce((
    select jsonb_agg(p.nick)
      from public.g2_players p
     where not p.banned
       and (
            (coalesce(p.save->'bp'->>'pr', '0') in ('1', 'true')
             and coalesce(p.save->'bp'->>'s', '') = coalesce(p_season, ''))
            or exists (select 1 from public.g2_gifts g
                        where g.to_key = p.key and g.pass = 'bp' and g.claimed_at is null)
            or exists (select 1 from public.g2_tr_offers o
                        where o.to_uid = p.uid and o.status = 'pending'
                          and public.g2_tr_gift(o.give, o.want))
       )
  ), '[]'::jsonb);
end;
$fn$;

-- ───── Друзья ─────
create table if not exists public.g2_friends (
  a_key      text        not null,                 -- кто отправил заявку
  b_key      text        not null,                 -- кому
  status     text        not null default 'pending' check (status in ('pending', 'accepted')),
  created_at timestamptz not null default now(),
  primary key (a_key, b_key),
  check (a_key <> b_key)
);
create index if not exists g2_friends_b_idx on public.g2_friends (b_key, status);
alter table public.g2_friends enable row level security;

create or replace function public.g2_friend_add(p_token text, p_nick text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  tg public.g2_players;
  ex public.g2_friends;
begin
  me := public.g2_auth(p_token);
  select * into tg from public.g2_players
   where key = lower(btrim(coalesce(p_nick, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if tg.key = me.key then raise exception 'Нельзя добавить себя в друзья'; end if;

  select * into ex from public.g2_friends
   where (a_key = me.key and b_key = tg.key) or (a_key = tg.key and b_key = me.key) limit 1;
  if found then
    if ex.status = 'accepted' then raise exception 'Вы уже друзья'; end if;
    if ex.a_key = me.key then raise exception 'Заявка уже отправлена'; end if;
    -- встречная заявка: сразу дружим
    update public.g2_friends set status = 'accepted' where a_key = ex.a_key and b_key = ex.b_key;
    return jsonb_build_object('status', 'accepted');
  end if;

  if (select count(*) from public.g2_friends where (a_key = me.key or b_key = me.key) and status = 'accepted') >= 100 then
    raise exception 'Слишком много друзей (макс. 100)';
  end if;
  if (select count(*) from public.g2_friends where a_key = me.key and status = 'pending') >= 30 then
    raise exception 'Слишком много исходящих заявок (макс. 30)';
  end if;

  insert into public.g2_friends (a_key, b_key) values (me.key, tg.key);
  return jsonb_build_object('status', 'pending');
end;
$fn$;

create or replace function public.g2_friend_respond(p_token text, p_nick text, p_accept boolean)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  tg public.g2_players;
begin
  me := public.g2_auth(p_token);
  select * into tg from public.g2_players where key = lower(btrim(coalesce(p_nick, '')));
  if not found then raise exception 'Игрок не найден'; end if;
  if coalesce(p_accept, false) then
    update public.g2_friends set status = 'accepted'
     where a_key = tg.key and b_key = me.key and status = 'pending';
  else
    delete from public.g2_friends where a_key = tg.key and b_key = me.key and status = 'pending';
  end if;
  if not found then raise exception 'Заявка уже не активна'; end if;
  return jsonb_build_object('ok', true);
end;
$fn$;

create or replace function public.g2_friend_remove(p_token text, p_nick text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  k  text := lower(btrim(coalesce(p_nick, '')));
begin
  me := public.g2_auth(p_token);
  delete from public.g2_friends
   where (a_key = me.key and b_key = k) or (a_key = k and b_key = me.key);
  return jsonb_build_object('ok', true);
end;
$fn$;

create or replace function public.g2_friend_list(p_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  fr jsonb; inc jsonb; outg jsonb;
begin
  me := public.g2_auth(p_token);

  select coalesce(jsonb_agg(jsonb_build_object('nick', u.nick,
           'avatar', case when length(u.avatar) < 200 then u.avatar else '' end) order by u.nick), '[]'::jsonb)
    into fr
    from public.g2_friends f
    join public.g2_players u on u.key = case when f.a_key = me.key then f.b_key else f.a_key end
   where f.status = 'accepted' and (f.a_key = me.key or f.b_key = me.key) and not u.banned;

  select coalesce(jsonb_agg(jsonb_build_object('nick', u.nick,
           'avatar', case when length(u.avatar) < 200 then u.avatar else '' end) order by f.created_at desc), '[]'::jsonb)
    into inc
    from public.g2_friends f join public.g2_players u on u.key = f.a_key
   where f.b_key = me.key and f.status = 'pending' and not u.banned;

  select coalesce(jsonb_agg(jsonb_build_object('nick', u.nick,
           'avatar', case when length(u.avatar) < 200 then u.avatar else '' end) order by f.created_at desc), '[]'::jsonb)
    into outg
    from public.g2_friends f join public.g2_players u on u.key = f.b_key
   where f.a_key = me.key and f.status = 'pending' and not u.banned;

  return jsonb_build_object('friends', fr, 'incoming', inc, 'outgoing', outg);
end;
$fn$;

do $g$
declare f text;
begin
  foreach f in array array[
    'g2_gift_bp(text, text)', 'g2_gift_claim(text)', 'g2_bp_owners(text, text)', 'g2_clear_profile(text, text)',
    'g2_friend_add(text, text)', 'g2_friend_respond(text, text, boolean)',
    'g2_friend_remove(text, text)', 'g2_friend_list(text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to anon, authenticated', f);
  end loop;
end
$g$;
