-- ============================================================================
-- 05 · ТОП И СПИСОК ИГРОКОВ ДЛЯ ПЕРЕВОДОВ (после 04)
-- Когда limit > 50 (выбор получателя), картинки-аватарки не отправляются — чтобы не гонять мегабайты.
-- Топ кланов лежит в 10_clans.sql.
-- Топ по монетам считается ПО МИРАМ: p_world = номер мира (0 — главный). Без p_world — как раньше (текущий мир игрока).
-- ============================================================================

-- монеты игрока в мире w (из сохранения). null — игрок в этот мир не заходил и портал не покупал.
--   текущий мир  → save.coins;  другой открытый мир → save.wd[w].coins (или 30, если ещё не заходил)
create or replace function public.g2_world_coins(sv jsonb, w int) returns numeric
language sql immutable as $fn$
  select case
    when w is null then coalesce((sv->>'coins')::numeric, 0)
    when (case when jsonb_typeof(sv->'w') = 'number' then (sv->>'w')::int else 0 end) = w
      then coalesce((sv->>'coins')::numeric, 0)
    when w = 0 or (jsonb_typeof(sv->'wu') = 'array' and sv->'wu' @> to_jsonb(w))
      then coalesce(case when jsonb_typeof(sv->'wd'->(w::text)->'coins') = 'number'
                         then (sv->'wd'->(w::text)->>'coins')::numeric end, 30)
    else null
  end
$fn$;

-- старая версия функции без p_world удаляется, иначе API не сможет выбрать между двумя перегрузками
drop function if exists public.g2_top(text, integer, text);

create or replace function public.g2_top(p_token text default null, p_limit integer default 20, p_by text default 'coins', p_world integer default null)
returns jsonb language plpgsql security definer set search_path = public as $fn$
declare
  me public.g2_players;
  lim int := least(greatest(coalesce(p_limit, 20), 1), 500);
  by_gem boolean := (p_by = 'gem');
  res jsonb;
  has_me boolean := false;
  mc numeric := 0; mg numeric := 0; rk bigint := 0;
begin
  if by_gem then
    select coalesce(jsonb_agg(jsonb_build_object('nick', t.nick, 'avatar', t.av, 'coins', floor(t.c), 'gem', floor(t.g))
                              order by t.g desc, t.c desc), '[]'::jsonb)
      into res
      from (select p.nick,
                   case when lim > 50 and p.avatar like 'data:%' then '😀' else p.avatar end as av,
                   public.g2_world_coins(p.save, null) as c,
                   coalesce((p.save->>'gem')::numeric, 0) as g
              from public.g2_players p
             where not p.banned
             order by coalesce((p.save->>'gem')::numeric, 0) desc, public.g2_world_coins(p.save, null) desc
             limit lim) t;
  else
    select coalesce(jsonb_agg(jsonb_build_object('nick', t.nick, 'avatar', t.av, 'coins', floor(t.c), 'gem', floor(t.g))
                              order by t.c desc, t.g desc), '[]'::jsonb)
      into res
      from (select p.nick,
                   case when lim > 50 and p.avatar like 'data:%' then '😀' else p.avatar end as av,
                   public.g2_world_coins(p.save, p_world) as c,
                   coalesce((p.save->>'gem')::numeric, 0) as g
              from public.g2_players p
             where not p.banned and public.g2_world_coins(p.save, p_world) is not null
             order by public.g2_world_coins(p.save, p_world) desc, coalesce((p.save->>'gem')::numeric, 0) desc
             limit lim) t;
  end if;

  if p_token is not null and p_token <> '' then
    select * into me from public.g2_players where token = p_token and not banned;
    has_me := found;
    if has_me then
      mc := floor(coalesce(public.g2_world_coins(me.save, case when by_gem then null else p_world end), 0));
      mg := floor(coalesce((me.save->>'gem')::numeric, 0));
      if by_gem then
        select count(*) + 1 into rk from public.g2_players
         where not banned and coalesce((save->>'gem')::numeric, 0) > mg;
      else
        select count(*) + 1 into rk from public.g2_players
         where not banned and public.g2_world_coins(save, p_world) > mc;
      end if;
      -- игрок в этот мир не заходил — места в этом топе у него нет
      if not by_gem and public.g2_world_coins(me.save, p_world) is null then has_me := false; end if;
    end if;
  end if;

  return jsonb_build_object('top', res,
    'me', case when has_me then jsonb_build_object('rank', rk, 'coins', mc, 'gem', mg) else null end);
end $fn$;
