-- ============================================================================
-- 10 · КЛАНЫ (после 09)
-- Ранги: owner (глава), coleader (со-глава), veteran, member.
-- Игрок привязан к клану по uid — смена ника ничего не ломает.
-- Создание клана стоит алмазов (тикетов), они списываются НА СЕРВЕРЕ (и поднимают ver).
-- ВКЛАД — в МОНЕТАХ: монеты списываются у игрока на сервере и попадают в КАЗНУ клана (bank),
-- а также двигают уровень клана (pool) и топ (total).
-- УЛУЧШЕНИЯ (вместимость, удача, доход, тикеты) покупаются за МОНЕТЫ ИЗ КАЗНЫ клана — у игрока ничего не списывается.
-- Файл можно запускать повторно поверх уже установленной базы.
-- ============================================================================

-- казна клана (для баз, созданных до этой версии)
alter table public.g2_clans add column if not exists bank bigint not null default 0;
do $do$ begin
  if not exists (select 1 from pg_constraint where conname = 'g2_clans_bank_check') then
    alter table public.g2_clans add constraint g2_clans_bank_check check (bank >= 0);
  end if;
end $do$;

-- цена создания клана: 500 тикетов
update public.g2_clan_cfg set create_cost = 500 where id = 1;

-- ───── Внутренние помощники ─────
create or replace function public._g2clan_cost(l int) returns bigint
language sql immutable as $fn$ select (500 * (l + 1) * (l + 1))::bigint $fn$;

-- цена улучшения: база по уровню × множитель (удача 1, доход 0.8, алмазы 1.2), округление до 10
create or replace function public._g2clan_perk_cost(p_perk text, l int) returns bigint
language sql immutable as $fn$
  select (round(((array[200,400,700,1100,1700,2600,3800,5500,8000,12000])[l + 1]
                 * (case p_perk when 'luck' then 1 when 'inc' then 0.8 else 1.2 end)) / 10) * 10)::bigint
$fn$;

-- списать алмазы у игрока (строка блокируется, версия растёт — устаревшие вкладки не вернут алмазы)
create or replace function public._g2clan_spend(p_key text, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $fn$
declare g numeric;
begin
  if p_amount is null or p_amount < 1 then raise exception 'Некорректная сумма'; end if;
  select floor(coalesce((save->>'gem')::numeric, 0)) into g
    from public.g2_players where key = p_key for update;
  if not found then raise exception 'Игрок не найден'; end if;
  if g < p_amount then raise exception 'Не хватает алмазов'; end if;
  update public.g2_players
     set save = jsonb_set(save, '{gem}', to_jsonb(g - p_amount)), ver = ver + 1
   where key = p_key;
end $fn$;

-- списать МОНЕТЫ у игрока (строка блокируется, версия растёт — устаревшие вкладки не вернут монеты)
create or replace function public._g2clan_spend_coins(p_key text, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $fn$
declare c numeric;
begin
  if p_amount is null or p_amount < 1 then raise exception 'Некорректная сумма'; end if;
  select floor(coalesce((save->>'coins')::numeric, 0)) into c
    from public.g2_players where key = p_key for update;
  if not found then raise exception 'Игрок не найден'; end if;
  if c < p_amount then raise exception 'Не хватает монет'; end if;
  update public.g2_players
     set save = jsonb_set(save, '{coins}', to_jsonb(c - p_amount)), ver = ver + 1
   where key = p_key;
end $fn$;

-- выйти из клана; если уходит глава — он переходит к со-главе, затем ветерану, затем самому старому участнику;
-- если участников не осталось — клан удаляется
create or replace function public._g2clan_leave(p_uid uuid) returns void
language plpgsql security definer set search_path = public as $fn$
declare m public.g2_clan_members; nxt public.g2_clan_members;
begin
  select * into m from public.g2_clan_members where uid = p_uid;
  if not found then return; end if;
  perform 1 from public.g2_clans where id = m.clan_id for update;
  delete from public.g2_clan_members where uid = p_uid;
  if m.role = 'owner' then
    select * into nxt from public.g2_clan_members where clan_id = m.clan_id
     order by case role when 'coleader' then 0 when 'veteran' then 1 else 2 end, joined_at
     limit 1;
    if found then
      update public.g2_clan_members set role = 'owner' where uid = nxt.uid;
    else
      delete from public.g2_clans where id = m.clan_id;
    end if;
  end if;
end $fn$;

-- ───── Информация ─────
create or replace function public.g2_clan_me(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; m public.g2_clan_members; c public.g2_clans; mem jsonb;
begin
  r := public.g2_auth(p_token);
  select * into m from public.g2_clan_members where uid = r.uid;
  if not found then return jsonb_build_object('clan', null); end if;
  select * into c from public.g2_clans where id = m.clan_id;
  select coalesce(jsonb_agg(jsonb_build_object('nick', p.nick, 'role', x.role, 'donated', x.donated)
                            order by x.donated desc, x.joined_at), '[]'::jsonb)
    into mem
    from public.g2_clan_members x join public.g2_players p on p.uid = x.uid
   where x.clan_id = c.id;
  return jsonb_build_object('clan', jsonb_build_object(
    'id', c.id, 'name', c.name, 'tag', c.tag, 'level', c.level, 'pool', c.pool, 'bank', c.bank,
    'next', case when c.level >= 10 then null else public._g2clan_cost(c.level) end,
    'mine', m.role, 'members', mem));
end $fn$;

create or replace function public.g2_clan_list(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  return coalesce((select jsonb_agg(t order by t.level desc, t.total desc, t.tag) from (
           select c.id, c.name, c.tag, c.level, c.total,
                  (select count(*) from public.g2_clan_members x where x.clan_id = c.id) as members
             from public.g2_clans c order by c.level desc, c.total desc, c.tag limit 30) t), '[]'::jsonb);
end $fn$;

-- топ кланов по вкладам в казну (total растёт с каждым вкладом, в том числе на 10 уровне)
create or replace function public.g2_clan_top(p_token text default null) returns jsonb
language sql stable security definer set search_path = public as $fn$
  select coalesce(jsonb_agg(t order by t.total desc, t.tag), '[]'::jsonb) from (
    select c.tag, c.name, c.level, c.total,
           (select count(*) from public.g2_clan_members x where x.clan_id = c.id) as members
      from public.g2_clans c order by c.total desc, c.tag limit 50) t
$fn$;

-- настройки вместимости и уровни всех кланов; токен не обязателен (сайт зовёт и без входа)
create or replace function public.g2_clan_caps(p_token text default null) returns jsonb
language sql stable security definer set search_path = public as $fn$
  select jsonb_build_object('base', c.base_cap, 'step', c.step, 'max', c.max_lvl, 'costs', c.costs,
           'lv', coalesce((select jsonb_object_agg(k.tag, k.cap_lvl) from public.g2_clans k where k.cap_lvl > 0), '{}'::jsonb))
    from public.g2_clan_cfg c where c.id = 1
$fn$;

-- улучшения своего клана: {"lv": {"luck": n, "inc": n, "gem": n}}
create or replace function public.g2_clan_perks(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; c public.g2_clans;
begin
  r := public.g2_auth(p_token);
  select k.* into c from public.g2_clans k
    join public.g2_clan_members m on m.clan_id = k.id where m.uid = r.uid;
  if not found then return jsonb_build_object('lv', jsonb_build_object('luck', 0, 'inc', 0, 'gem', 0)); end if;
  return jsonb_build_object('lv', jsonb_build_object('luck', c.perk_luck, 'inc', c.perk_inc, 'gem', c.perk_gem));
end $fn$;

-- ───── Создание / вступление / выход ─────
create or replace function public.g2_clan_create(p_token text, p_name text, p_tag text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; nm text; tg text; cid bigint; cost bigint;
begin
  r := public.g2_auth(p_token);
  nm := btrim(coalesce(p_name, '')); tg := upper(btrim(coalesce(p_tag, '')));
  if char_length(nm) < 3 or char_length(nm) > 16 then raise exception 'Название: 3–16 символов'; end if;
  if nm ~ '[<>[:cntrl:]]' then raise exception 'Название содержит недопустимые символы'; end if;
  if tg !~ '^[A-Z0-9]{2,4}$' then raise exception 'Тег: 2–4 символа, латиница или цифры'; end if;
  if exists (select 1 from public.g2_clan_members where uid = r.uid) then raise exception 'Ты уже в клане'; end if;
  select create_cost into cost from public.g2_clan_cfg where id = 1;
  begin
    insert into public.g2_clans(name, tag) values (nm, tg) returning id into cid;
  exception when unique_violation then
    raise exception 'Название или тег уже заняты';
  end;
  perform public._g2clan_spend(r.key, cost);                  -- не хватает алмазов — вся операция откатится
  insert into public.g2_clan_members(uid, clan_id, role) values (r.uid, cid, 'owner');
  return jsonb_build_object('ok', true, 'id', cid);
end $fn$;

-- вступить с проверкой вместимости (старое имя оставлено для совместимости)
create or replace function public.g2_clan_join(p_token text, p_id bigint) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; c public.g2_clans; cfg public.g2_clan_cfg; cnt int;
begin
  r := public.g2_auth(p_token);
  if exists (select 1 from public.g2_clan_members where uid = r.uid) then raise exception 'Ты уже в клане'; end if;
  select * into c from public.g2_clans where id = p_id for update;   -- блокировка: места не «перебронируют»
  if not found then raise exception 'Клан не найден'; end if;
  select * into cfg from public.g2_clan_cfg where id = 1;
  select count(*) into cnt from public.g2_clan_members where clan_id = c.id;
  if cnt >= cfg.base_cap + cfg.step * c.cap_lvl then raise exception 'В клане нет свободных мест'; end if;
  insert into public.g2_clan_members(uid, clan_id) values (r.uid, c.id);
  return jsonb_build_object('ok', true);
end $fn$;

create or replace function public.g2_clan_join_cap(p_token text, p_id bigint) returns jsonb
language sql security definer set search_path = public as $fn$
  select public.g2_clan_join(p_token, p_id)
$fn$;

create or replace function public.g2_clan_leave(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if not exists (select 1 from public.g2_clan_members where uid = r.uid) then raise exception 'Ты не в клане'; end if;
  perform public._g2clan_leave(r.uid);
  return jsonb_build_object('ok', true);
end $fn$;

-- ───── Казна ─────
-- вклад МОНЕТАМИ: списывается у игрока, попадает в казну (bank), двигает уровень клана (pool)
-- и топ (total). Работает и на 10 уровне — тогда уровень не растёт, но казна и топ копятся.
drop function if exists public.g2_clan_donate(text, bigint);   -- старый вклад алмазами убран
create or replace function public.g2_clan_donate_coins(p_token text, p_coins numeric) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; m public.g2_clan_members; c public.g2_clans; amt bigint;
begin
  r := public.g2_auth(p_token);
  if p_coins is null or p_coins < 1 or p_coins > 9000000000000000 then raise exception 'Некорректная сумма'; end if;
  amt := floor(p_coins)::bigint;
  select * into m from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Ты не в клане'; end if;
  select * into c from public.g2_clans where id = m.clan_id for update;
  perform public._g2clan_spend_coins(r.key, amt);             -- не хватает монет — вся операция откатится
  c.bank := c.bank + amt;
  if c.level < 10 then
    c.pool := c.pool + amt;
    while c.level < 10 and c.pool >= public._g2clan_cost(c.level) loop
      c.pool  := c.pool - public._g2clan_cost(c.level);
      c.level := c.level + 1;
    end loop;
    if c.level >= 10 then c.pool := 0; end if;
  end if;
  update public.g2_clans set pool = c.pool, level = c.level, bank = c.bank, total = total + amt where id = c.id;
  update public.g2_clan_members set donated = donated + amt where uid = r.uid;
  return jsonb_build_object('ok', true, 'level', c.level, 'bank', c.bank);
end $fn$;

-- прокачать вместимость (только глава) — за монеты из казны
create or replace function public.g2_clan_cap_up(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; m public.g2_clan_members; c public.g2_clans; cfg public.g2_clan_cfg; cost numeric;
begin
  r := public.g2_auth(p_token);
  select * into m from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Вы не в клане'; end if;
  if m.role <> 'owner' then raise exception 'Только владелец клана может прокачивать вместимость'; end if;
  select * into c from public.g2_clans where id = m.clan_id for update;
  select * into cfg from public.g2_clan_cfg where id = 1;
  if c.cap_lvl >= cfg.max_lvl then raise exception 'Вместимость уже максимальная'; end if;
  cost := (cfg.costs ->> c.cap_lvl)::numeric;
  if c.bank < cost then raise exception 'В казне не хватает монет'; end if;
  update public.g2_clans set cap_lvl = cap_lvl + 1, bank = bank - cost::bigint where id = c.id;
  return jsonb_build_object('ok', true, 'lvl', c.cap_lvl + 1, 'cap', cfg.base_cap + cfg.step * (c.cap_lvl + 1),
                            'cost', cost, 'bank', c.bank - cost::bigint);
end $fn$;

-- улучшение клана: luck / inc / gem (глава или со-глава) — за монеты из казны
create or replace function public.g2_clan_perk_up(p_token text, p_perk text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; m public.g2_clan_members; c public.g2_clans; lv int; cost bigint;
begin
  if p_perk is null or p_perk not in ('luck', 'inc', 'gem') then raise exception 'Неизвестное улучшение'; end if;
  r := public.g2_auth(p_token);
  select * into m from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Вы не в клане'; end if;
  if m.role not in ('owner', 'coleader') then raise exception 'Улучшения покупает глава или со-глава клана'; end if;
  select * into c from public.g2_clans where id = m.clan_id for update;
  lv := case p_perk when 'luck' then c.perk_luck when 'inc' then c.perk_inc else c.perk_gem end;
  if lv >= 10 then raise exception 'Улучшение уже максимальное'; end if;
  cost := public._g2clan_perk_cost(p_perk, lv);
  if c.bank < cost then raise exception 'В казне не хватает монет'; end if;
  update public.g2_clans set
         bank      = bank - cost,
         perk_luck = perk_luck + case when p_perk = 'luck' then 1 else 0 end,
         perk_inc  = perk_inc  + case when p_perk = 'inc'  then 1 else 0 end,
         perk_gem  = perk_gem  + case when p_perk = 'gem'  then 1 else 0 end
   where id = c.id;
  return jsonb_build_object('ok', true, 'lvl', lv + 1, 'cost', cost, 'bank', c.bank - cost);
end $fn$;

-- ───── Управление участниками ─────
create or replace function public.g2_clan_set_rank(p_token text, p_nick text, p_rank text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; me public.g2_clan_members; t public.g2_clan_members; rk text;
begin
  r := public.g2_auth(p_token);
  select * into me from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Вы не в клане'; end if;
  if me.role not in ('owner', 'coleader') then raise exception 'Недостаточно прав'; end if;
  perform 1 from public.g2_clans where id = me.clan_id for update;   -- не гоняемся с выходом/вступлением
  rk := coalesce(nullif(p_rank, ''), 'member');
  if rk not in ('member', 'veteran', 'coleader') then raise exception 'Некорректный ранг'; end if;
  if rk = 'coleader' and me.role <> 'owner' then raise exception 'Со-главу назначает только глава'; end if;
  select m.* into t from public.g2_clan_members m join public.g2_players p on p.uid = m.uid
   where p.key = lower(btrim(coalesce(p_nick, ''))) and m.clan_id = me.clan_id;
  if not found then raise exception 'Игрок не состоит в вашем клане'; end if;
  if t.uid = me.uid then raise exception 'Нельзя менять свой ранг'; end if;
  if t.role = 'owner' then raise exception 'Нельзя менять ранг главы'; end if;
  if t.role = 'coleader' and me.role <> 'owner' then raise exception 'Нельзя менять ранг со-главы'; end if;
  update public.g2_clan_members set role = rk where uid = t.uid;
  return jsonb_build_object('ok', true);
end $fn$;

-- исключить участника: глава (кого угодно) или со-глава (кроме главы и других со-глав)
create or replace function public.g2_clan_kick(p_token text, p_nick text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; me public.g2_clan_members; t public.g2_clan_members;
begin
  r := public.g2_auth(p_token);
  select * into me from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Вы не в клане'; end if;
  if me.role not in ('owner', 'coleader') then raise exception 'Только глава или со-глава может исключать участников'; end if;
  perform 1 from public.g2_clans where id = me.clan_id for update;   -- не гоняемся с выходом/вступлением
  select m.* into t from public.g2_clan_members m join public.g2_players p on p.uid = m.uid
   where p.key = lower(btrim(coalesce(p_nick, ''))) and m.clan_id = me.clan_id;
  if not found then raise exception 'Игрок не состоит в вашем клане'; end if;
  if t.uid = me.uid then raise exception 'Нельзя исключить самого себя'; end if;
  if t.role = 'owner' then raise exception 'Нельзя исключить главу'; end if;
  if t.role = 'coleader' and me.role <> 'owner' then raise exception 'Со-главу исключает только глава'; end if;
  delete from public.g2_clan_members where uid = t.uid;
  return jsonb_build_object('ok', true);
end $fn$;

-- настройки: название и тег (только глава)
create or replace function public.g2_clan_edit(p_token text, p_name text, p_tag text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; me public.g2_clan_members; nm text; tg text;
begin
  r := public.g2_auth(p_token);
  select * into me from public.g2_clan_members where uid = r.uid;
  if not found then raise exception 'Вы не в клане'; end if;
  if me.role <> 'owner' then raise exception 'Только глава может менять настройки клана'; end if;
  nm := btrim(coalesce(p_name, '')); tg := upper(btrim(coalesce(p_tag, '')));
  if char_length(nm) < 3 or char_length(nm) > 16 then raise exception 'Название: 3–16 символов'; end if;
  if nm ~ '[<>[:cntrl:]]' then raise exception 'Название содержит недопустимые символы'; end if;
  if tg !~ '^[A-Z0-9]{2,4}$' then raise exception 'Тег: 2–4 символа, латиница или цифры'; end if;
  begin
    update public.g2_clans set name = nm, tag = tg where id = me.clan_id;
  exception when unique_violation then
    raise exception 'Название или тег уже заняты';
  end;
  return jsonb_build_object('ok', true, 'name', nm, 'tag', tg);
end $fn$;
