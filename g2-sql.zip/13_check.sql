-- ============================================================================
-- 13 · ПРОВЕРКА УСТАНОВКИ (только читает, ничего не меняет)
-- Должно вернуться 0 строк в обоих запросах.
-- ============================================================================

-- 1) функции, которые вызывает сайт, но которых нет или к которым нет доступа
select n as problem_function
from unnest(array[
  'g2_register','g2_login','g2_me','g2_is_banned','g2_save','g2_claim','g2_set_avatar',
  'g2_change_nick','g2_change_password','g2_delete_account','g2_top','g2_players','g2_profile','g2_set_role',
  'g2_admin_get','g2_admin_set','g2_clear_profile','g2_reset_all','g2_ban','g2_mod_list','g2_mod_log_list','g2_admin_log','g2_event_get',
  'g2_event_set','g2_event_stop','g2_event_auto','g2_promo_redeem','g2_promo_create',
  'g2_promo_list','g2_promo_delete','g2_trade_partner','g2_trade_send','g2_trade_respond',
  'g2_trade_sync','g2_trade_list','g2_clan_me','g2_clan_list','g2_clan_top','g2_clan_create',
  'g2_clan_join','g2_clan_join_cap','g2_clan_leave','g2_clan_donate_coins','g2_clan_set_rank',
  'g2_clan_kick','g2_clan_edit','g2_clan_caps','g2_clan_cap_up','g2_clan_perks','g2_clan_perk_up'
]) as n
where not exists (select 1 from pg_proc p
                   where p.pronamespace = 'public'::regnamespace and p.proname = n
                     and has_function_privilege('anon', p.oid, 'execute'));

-- 2) лишнее: функции проекта, доступные анониму, но не нужные сайту (внутренние помощники), и открытые таблицы
select p.oid::regprocedure::text as exposed
  from pg_proc p
 where p.pronamespace = 'public'::regnamespace
   and (p.proname like 'g2\_tr\_%' or p.proname like '\_g2clan\_%'
        or p.proname in ('g2_auth','g2_world_coins','g2_diff_save','g2_fresh','g2_av','g2_clean_save','g2_save_ok','g2_save_out',
                         'g2_payload','g2_new_token','g2_merge_mono','g2_auto_pick','g2_auto_ev'))
   and has_function_privilege('anon', p.oid, 'execute')
union all
select 'table ' || c.relname
  from pg_class c
 where c.relnamespace = 'public'::regnamespace and c.relkind = 'r' and c.relname like 'g2\_%'
   and (has_table_privilege('anon', c.oid, 'select') or not c.relrowsecurity);
