-- ============================================================================
-- 03 · АККАУНТЫ: регистрация, вход, профиль (после 02)
-- Первый зарегистрированный игрок становится владельцем (owner).
-- ============================================================================

create or replace function public.g2_register(p_nick text, p_pass text, p_avatar text, p_save jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $fn$
declare k text; r public.g2_players; ep int; first_user boolean;
begin
  perform pg_advisory_xact_lock(7001);
  p_nick := trim(coalesce(p_nick, ''));
  if p_nick !~ '^[A-Za-z0-9_А-Яа-яЁё-]{3,16}$' then
    raise exception 'Ник: 3–16 символов — буквы, цифры, _ и -';
  end if;
  if length(coalesce(p_pass, '')) < 4 or length(p_pass) > 72 then
    raise exception 'Пароль: минимум 4 символа';
  end if;
  k := lower(p_nick);
  if exists (select 1 from public.g2_players where key = k) then
    raise exception 'Этот ник уже занят';
  end if;
  select epoch into ep from public.g2_meta where id = 1;
  first_user := not exists (select 1 from public.g2_players);
  insert into public.g2_players(key, nick, avatar, pass_hash, role, save, token, epoch)
  values (k, p_nick, public.g2_av(p_avatar), crypt(p_pass, gen_salt('bf')),
          case when first_user then 'owner' else '' end,
          public.g2_clean_save(p_save), public.g2_new_token(), ep)
  returning * into r;
  return public.g2_payload(r);
end $fn$;

create or replace function public.g2_login(p_nick text, p_pass text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; ep int;
begin
  select * into r from public.g2_players where key = lower(trim(coalesce(p_nick, '')));
  if found and r.banned then
    raise exception 'Аккаунт заблокирован%', case when coalesce(r.ban_reason, '') <> '' then ': ' || r.ban_reason else '' end;
  end if;
  if not found or r.pass_hash <> crypt(coalesce(p_pass, ''), r.pass_hash) then
    perform pg_sleep(0.5);                                  -- замедляем перебор паролей
    raise exception 'Неверный ник или пароль';
  end if;
  select epoch into ep from public.g2_meta where id = 1;
  if r.epoch <> ep then
    update public.g2_players set epoch = ep where key = r.key returning * into r;
  end if;
  return public.g2_payload(r);
end $fn$;

create or replace function public.g2_me(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; ep int;
begin
  r := public.g2_auth(p_token);
  select epoch into ep from public.g2_meta where id = 1;
  if r.epoch <> ep then
    update public.g2_players set epoch = ep where key = r.key returning * into r;
  end if;
  return public.g2_payload(r);
end $fn$;

-- заблокирован ли ник (нужно экрану входа, чтобы показать причину)
create or replace function public.g2_is_banned(p_nick text) returns jsonb
language sql stable security definer set search_path = public as $fn$
  select coalesce((select jsonb_build_object('banned', banned, 'reason', coalesce(ban_reason, ''))
                     from public.g2_players where key = lower(trim(coalesce(p_nick, '')))),
                  '{"banned":false}'::jsonb)
$fn$;

create or replace function public.g2_set_avatar(p_token text, p_avatar text) returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  update public.g2_players set avatar = public.g2_av(p_avatar) where key = r.key;
end $fn$;

-- смена пароля выдаёт новый токен: остальные устройства разлогиниваются
create or replace function public.g2_change_password(p_token text, p_old text, p_new text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; t text;
begin
  r := public.g2_auth(p_token);
  if r.pass_hash <> crypt(coalesce(p_old, ''), r.pass_hash) then
    perform pg_sleep(0.5);
    raise exception 'Текущий пароль неверный';
  end if;
  if length(coalesce(p_new, '')) < 4 or length(p_new) > 72 then
    raise exception 'Новый пароль: минимум 4 символа';
  end if;
  t := public.g2_new_token();
  update public.g2_players set pass_hash = crypt(p_new, gen_salt('bf')), token = t where key = r.key;
  return jsonb_build_object('token', t);
end $fn$;

-- удаление аккаунта: сначала аккуратно выходим из клана (передаём главу), остальное чистят внешние ключи
create or replace function public.g2_delete_account(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players;
begin
  r := public.g2_auth(p_token);
  if r.role = 'owner' then raise exception 'Владелец не может удалить аккаунт'; end if;
  perform public._g2clan_leave(r.uid);
  delete from public.g2_players where key = r.key;
  return jsonb_build_object('ok', true);
end $fn$;

-- смена ника раз в 7 дней. Клан, трейды и промокоды привязаны к uid — ничего «терять» не нужно
create or replace function public.g2_change_nick(p_token text, p_nick text) returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; k text; now_ms bigint; left_ms bigint;
begin
  perform pg_advisory_xact_lock(7001);
  r := public.g2_auth(p_token);
  p_nick := trim(coalesce(p_nick, ''));
  if p_nick !~ '^[A-Za-z0-9_А-Яа-яЁё-]{3,16}$' then
    raise exception 'Ник: 3–16 символов — буквы, цифры, _ и -';
  end if;
  now_ms  := (extract(epoch from now()) * 1000)::bigint;
  left_ms := r.nick_at + 7 * 86400000 - now_ms;
  if r.nick_at > 0 and left_ms > 0 then
    raise exception 'Ник можно сменить через % дн.', ceil(left_ms / 86400000.0)::int;
  end if;
  k := lower(p_nick);
  if k <> r.key and exists (select 1 from public.g2_players where key = k) then
    raise exception 'Этот ник уже занят';
  end if;
  update public.g2_players set key = k, nick = p_nick, nick_at = now_ms where key = r.key;
end $fn$;

-- публичный профиль игрока по нику (аватар для списков: топ, трейды, клан). Раньше сайт звал её, а в базе её не было.
create or replace function public.g2_profile(p_token text, p_nick text) returns jsonb
language plpgsql security definer set search_path = public as $fn$
declare r public.g2_players; t public.g2_players;
begin
  r := public.g2_auth(p_token);
  select * into t from public.g2_players where lower(nick) = lower(btrim(coalesce(p_nick, ''))) and not banned;
  if not found then return null; end if;
  return jsonb_build_object('nick', t.nick, 'avatar', t.avatar);
end $fn$;
