-- ============================================================================
-- 12 · ПРАВА ДОСТУПА (после 11; запускать ПОСЛЕДНИМ из установочных; можно повторно после любых изменений функций)
-- 1) таблицы и последовательности закрыты: всё идёт только через функции (они работают от имени владельца базы);
-- 2) у ВСЕХ функций проекта сначала отбирается доступ, потом открывается только список ниже —
--    то есть то, что реально вызывает сайт. Служебные g2_auth, g2_tr_*, _g2clan_* и т.п. остаются закрытыми.
-- ============================================================================

-- таблицы и последовательности проекта
do $do$
declare r record;
begin
  for r in select relname, relkind from pg_class
            where relnamespace = 'public'::regnamespace and relkind in ('r', 'S') and relname like 'g2\_%'
  loop
    if r.relkind = 'S' then
      execute format('revoke all on sequence public.%I from public, anon, authenticated', r.relname);
    else
      execute format('revoke all on table public.%I from public, anon, authenticated', r.relname);
    end if;
  end loop;
end $do$;

-- функции
do $do$
declare
  r record;
  site text[] := array[
    -- аккаунт и сохранение
    'g2_register', 'g2_login', 'g2_me', 'g2_is_banned', 'g2_save', 'g2_claim',
    'g2_set_avatar', 'g2_change_nick', 'g2_change_password', 'g2_delete_account',
    -- топ
    'g2_top', 'g2_players', 'g2_profile',
    -- админка и модерация (внутри каждой — проверка роли)
    'g2_set_role', 'g2_admin_get', 'g2_admin_set', 'g2_clear_profile', 'g2_reset_all',
    'g2_ban', 'g2_mod_list', 'g2_mod_log_list', 'g2_admin_log',
    -- ивенты
    'g2_event_get', 'g2_event_set', 'g2_event_stop', 'g2_event_auto',
    -- промокоды
    'g2_promo_redeem', 'g2_promo_create', 'g2_promo_list', 'g2_promo_delete',
    -- трейды
    'g2_trade_partner', 'g2_trade_send', 'g2_trade_respond', 'g2_trade_sync', 'g2_trade_list',
    -- кланы
    'g2_clan_me', 'g2_clan_list', 'g2_clan_top', 'g2_clan_create', 'g2_clan_join',
    'g2_clan_join_cap', 'g2_clan_leave', 'g2_clan_donate_coins', 'g2_clan_set_rank', 'g2_clan_kick',
    'g2_clan_edit', 'g2_clan_caps', 'g2_clan_cap_up', 'g2_clan_perks', 'g2_clan_perk_up',
    -- подарки геймпассов и VIP-тег (06_gifts.sql)
    'g2_gift_pass', 'g2_gift_claim', 'g2_vip_list', 'g2_pass_owners', 'g2_bp_owners', 'g2_gift_note', 'g2_gift_history', 'g2_gift_bp', 'g2_friend_add', 'g2_friend_respond', 'g2_friend_remove', 'g2_friend_list', 'g2_idea_add', 'g2_idea_list', 'g2_idea_vote', 'g2_idea_delete', 'g2_idea_status'
  ];
  n text;
begin
  for r in select p.oid::regprocedure::text as sig, p.proname
             from pg_proc p
            where p.pronamespace = 'public'::regnamespace
              and (p.proname like 'g2\_%' or p.proname like '\_g2clan\_%')
  loop
    execute 'revoke all on function ' || r.sig || ' from public, anon, authenticated';
    if r.proname = any(site) then
      execute 'grant execute on function ' || r.sig || ' to anon, authenticated';
    end if;
  end loop;

  -- страховка: если какой-то функции из списка нет в базе, скажем об этом сразу
  foreach n in array site loop
    if not exists (select 1 from pg_proc where pronamespace = 'public'::regnamespace and proname = n) then
      raise warning 'Функция % не найдена — запусти предыдущие файлы по порядку', n;
    end if;
  end loop;
end $do$;

notify pgrst, 'reload schema';
