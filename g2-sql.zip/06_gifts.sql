-- 06_gifts.sql — подарки геймпассов + VIP-тег в топе (v2)
-- Выполнить целиком в Supabase → SQL Editor (можно повторно).
--
-- ИСПРАВЛЕНО: «integer out of range» — тикеты у игроков огромные (1T и больше),
-- а раньше остаток считался как int (макс. ~2 млрд). Теперь всё в numeric.
-- Также: подарок бампит версию сохранения (ver), чтобы клиент сразу подхватывал
-- актуальные тикеты/пассы, а старая вкладка не могла затереть списание (дюп).

-- 1) Таблица подарков ---------------------------------------------------
create table if not exists public.g2_gifts (
  id         bigserial primary key,
  from_key   text        not null,
  to_key     text        not null,
  pass       text        not null,
  price      numeric     not null,
  created_at timestamptz not null default now(),
  claimed_at timestamptz
);
-- если таблица создана старой версией с price int — расширяем
alter table public.g2_gifts alter column price type numeric;
create index if not exists g2_gifts_to_pending
  on public.g2_gifts (to_key) where claimed_at is null;
alter table public.g2_gifts enable row level security;

-- быстрый список VIP
create index if not exists g2_players_vip_idx
  on public.g2_players (key) where (save->'gp'->>'vip') in ('1','true');

-- 2) Подарить пасс ------------------------------------------------------
create or replace function public.g2_gift_pass(p_token text, p_to text, p_pass text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me      public.g2_players;
  tg      public.g2_players;
  v_base  numeric;
  v_price numeric;
  v_gem   numeric;
  v_new   numeric;
  v_ver   bigint;
begin
  v_base := case p_pass
              when 'vip'   then 600
              when 'coin'  then 300
              when 'luck'  then 200
              when 'disc'  then 250
              when 'daily' then 120
            end;
  if v_base is null then
    raise exception 'Неизвестный пасс';
  end if;

  me := public.g2_auth(p_token);
  select * into me from public.g2_players where key = me.key for update;

  select * into tg from public.g2_players
   where key = lower(btrim(coalesce(p_to, ''))) and not banned;
  if not found then
    raise exception 'Игрок не найден';
  end if;
  if tg.key = me.key then
    raise exception 'Нельзя дарить себе';
  end if;

  if coalesce(tg.save->'gp'->>p_pass, '0') in ('1', 'true')
     or exists (select 1 from public.g2_gifts
                 where to_key = tg.key and pass = p_pass and claimed_at is null) then
    raise exception 'У игрока уже есть этот пасс';
  end if;

  v_price := floor(v_base * case when coalesce(me.save->'gp'->>'vip', '0') in ('1', 'true')
                                 then 0.9 else 1 end);

  v_gem := case when jsonb_typeof(me.save->'gem') = 'number' then (me.save->>'gem')::numeric else 0 end;
  if v_gem < v_price then
    raise exception 'Не хватает тикетов';
  end if;
  v_new := floor(v_gem - v_price);

  update public.g2_players
     set save = jsonb_set(save, '{gem}', to_jsonb(v_new)),
         ver  = ver + 1
   where key = me.key
   returning ver into v_ver;

  insert into public.g2_gifts (from_key, to_key, pass, price)
  values (me.key, tg.key, p_pass, v_price);

  return jsonb_build_object('ok', true, 'gem', v_new, 'v', v_ver);
end;
$fn$;

-- 3) Забрать входящие подарки ------------------------------------------
create or replace function public.g2_gift_claim(p_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me     public.g2_players;
  r      record;
  v_list jsonb := '[]'::jsonb;
  v_ver  bigint;
begin
  me := public.g2_auth(p_token);
  select * into me from public.g2_players where key = me.key for update;
  v_ver := me.ver;

  for r in
    select g.id, g.pass,
           (select u.nick from public.g2_players u where u.key = g.from_key) as from_nick
      from public.g2_gifts g
     where g.to_key = me.key and g.claimed_at is null
     order by g.id
       for update of g
  loop
    update public.g2_gifts set claimed_at = now() where id = r.id;

    update public.g2_players
       set save = jsonb_set(
             case when jsonb_typeof(save->'gp') = 'object' then save
                  else jsonb_set(save, '{gp}', '{}'::jsonb) end,
             array['gp', r.pass], '1'::jsonb)
     where key = me.key;

    v_list := v_list || jsonb_build_object('pass', r.pass, 'from', r.from_nick);
  end loop;

  if jsonb_array_length(v_list) > 0 then
    update public.g2_players set ver = ver + 1 where key = me.key returning ver into v_ver;
  end if;

  return jsonb_build_object('gifts', v_list, 'v', v_ver);
end;
$fn$;

-- 4) Список ников с VIP (тег в топе): купленный VIP + подаренный, ещё не забранный ----
create or replace function public.g2_vip_list()
returns jsonb
language sql
stable
security definer
set search_path = public
as $fn$
  select coalesce(jsonb_agg(distinct lower(x.nick)), '[]'::jsonb)
  from (
    select p.nick
      from public.g2_players p
     where (p.save->'gp'->>'vip') in ('1', 'true') and not p.banned
    union all
    select p.nick
      from public.g2_gifts g
      join public.g2_players p on p.key = g.to_key
     where g.pass = 'vip' and g.claimed_at is null and not p.banned
  ) x;
$fn$;

-- 5) Права --------------------------------------------------------------
revoke all on function public.g2_gift_pass(text, text, text) from public;
revoke all on function public.g2_gift_claim(text)            from public;
revoke all on function public.g2_vip_list()                  from public;
grant execute on function public.g2_gift_pass(text, text, text) to anon, authenticated;
grant execute on function public.g2_gift_claim(text)            to anon, authenticated;
grant execute on function public.g2_vip_list()                  to anon, authenticated;

notify pgrst, 'reload schema';
