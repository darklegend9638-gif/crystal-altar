-- ============================================================================
-- 01 · ТАБЛИЦЫ, ИНДЕКСЫ, RLS
-- Можно запускать повторно: ничего не удаляет, только добавляет недостающее.
-- Дальше по порядку: 02 helpers → 03 accounts → 04 save → 05 top → 06 admin →
--                    07 events → 08 promo → 09 trade → 10 clans → 11 trade_age → 12 permissions → 13 check
-- ============================================================================

create extension if not exists pgcrypto with schema extensions;

-- Новые функции по умолчанию закрыты для сайта. Открывает только 12_permissions.sql,
-- поэтому забытая служебная функция не станет публичной.
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;

-- ───── Игроки ─────
create table if not exists public.g2_players(
  uid         uuid        not null default gen_random_uuid() unique,  -- постоянный id (ник можно менять)
  key         text        primary key,                                -- lower(ник)
  nick        text        not null,
  avatar      text        not null default '😀',
  pass_hash   text        not null,
  pass_bak    text,                                                   -- хеш пароля на время бана
  role        text        not null default '' check (role in ('', 'admin', 'owner')),
  save        jsonb       not null default '{}'::jsonb,
  ver         bigint      not null default 0,                         -- версия сохранения (защита от дюпов)
  token       text        unique,
  nick_at     bigint      not null default 0,
  epoch       integer     not null default 0,
  inbox       numeric     not null default 0 check (inbox >= 0),      -- входящие монеты (g2_claim)
  inbox_from  text        not null default '',
  banned      boolean     not null default false,
  ban_reason  text,
  created_at  timestamptz not null default now()
);

create index if not exists g2_players_coins_idx on public.g2_players (coalesce((save->>'coins')::numeric, 0::numeric) desc);
create index if not exists g2_players_gem_idx   on public.g2_players (coalesce((save->>'gem')::numeric,   0::numeric) desc);

-- ───── Служебные ─────
create table if not exists public.g2_mod_log(
  id     bigserial primary key,
  ts     timestamptz not null default now(),
  actor  text not null,
  target text not null,
  action text not null,
  reason text,
  detail text                       -- что именно сделано: «монеты +1000 (500→1500)» и т.п.
);
create index if not exists g2_mod_log_ts_idx on public.g2_mod_log (ts desc);

create table if not exists public.g2_meta(
  id    integer primary key default 1 check (id = 1),
  epoch integer not null default 0
);
insert into public.g2_meta(id, epoch) values (1, 0) on conflict (id) do nothing;

-- ───── Ивенты ─────
create table if not exists public.g2_event(
  id       integer primary key default 1 check (id = 1),
  auto_on  boolean not null default true,
  auto_len integer not null default 15            -- сколько минут каждого часа идёт автоивент
);
insert into public.g2_event(id) values (1) on conflict (id) do nothing;

create table if not exists public.g2_event_cfg(
  ev     text primary key,
  weight numeric not null check (weight >= 0),
  tier   text
);
create table if not exists public.g2_event_live(
  ev    text primary key,
  until timestamptz not null
);

-- ───── Промокоды ─────
create table if not exists public.g2_promos(
  code       text primary key,                    -- всегда в верхнем регистре
  coins      numeric not null default 0,
  gems       numeric not null default 0,
  max_uses   int,                                 -- null = без лимита
  uses       int not null default 0,
  expires_at timestamptz,                         -- null = без срока
  created_by text,
  created_at timestamptz not null default now()
);
create table if not exists public.g2_promo_uses(
  code    text not null references public.g2_promos(code) on delete cascade,
  uid     uuid not null references public.g2_players(uid) on delete cascade,
  used_at timestamptz not null default now(),
  primary key (code, uid)
);

-- ───── Трейды ─────
create table if not exists public.g2_tr_offers(
  id         bigserial primary key,
  from_uid   uuid not null references public.g2_players(uid) on delete cascade,
  to_uid     uuid not null references public.g2_players(uid) on delete cascade,
  give       jsonb not null,                      -- что отдаёт предлагающий
  want       jsonb not null,                      -- что просит взамен
  status     text not null default 'pending'
             check (status in ('pending', 'done', 'declined', 'cancelled', 'expired')),
  epoch      int not null default 0,
  created_at timestamptz not null default now(),
  done_at    timestamptz
);
create index if not exists g2_tr_offers_to_idx   on public.g2_tr_offers(to_uid, status);
create index if not exists g2_tr_offers_from_idx on public.g2_tr_offers(from_uid, status);
-- g2_tr_gc() запускается при каждом опросе — ему нужен быстрый доступ только к активным предложениям
create index if not exists g2_tr_offers_pending_idx on public.g2_tr_offers(created_at) where status = 'pending';

-- накопленные изменения инвентаря: предметы + "$coins" + "$gems"
create table if not exists public.g2_tr_adj(
  uid   uuid primary key references public.g2_players(uid) on delete cascade,
  ia    jsonb not null default '{}'::jsonb,
  epoch int not null default 0
);

-- ───── Кланы ─────
-- Вместимость и улучшения лежат прямо в строке клана: отдельные таблицы «по тегу» больше не нужны,
-- поэтому новый клан с тем же тегом не может унаследовать чужую прокачку.
create table if not exists public.g2_clan_cfg(
  id          int primary key default 1 check (id = 1),
  base_cap    int    not null default 15,                                    -- мест без прокачки
  step        int    not null default 3,                                     -- мест за уровень вместимости
  max_lvl     int    not null default 5,                                     -- уровней вместимости
  costs       jsonb  not null default '[1500,3000,6000,10000,15000]'::jsonb, -- цена каждого уровня вместимости, 🪙 из казны
  create_cost bigint not null default 500                                    -- цена создания клана, 💎
);
insert into public.g2_clan_cfg(id) values (1) on conflict do nothing;

create table if not exists public.g2_clans(
  id         bigserial primary key,
  name       text   not null check (char_length(name) between 3 and 16),
  tag        text   not null check (tag ~ '^[A-Z0-9]{2,4}$'),
  level      int    not null default 0 check (level between 0 and 10),
  pool       bigint not null default 0 check (pool >= 0),     -- копится до следующего уровня
  total      bigint not null default 0,                       -- всего вложено (для топа кланов)
  bank       bigint not null default 0 check (bank >= 0),     -- КАЗНА: монеты, из неё платятся улучшения клана
  cap_lvl    int    not null default 0 check (cap_lvl >= 0),  -- прокачка вместимости
  perk_luck  int    not null default 0 check (perk_luck between 0 and 10),
  perk_inc   int    not null default 0 check (perk_inc  between 0 and 10),
  perk_gem   int    not null default 0 check (perk_gem  between 0 and 10),
  created_at timestamptz not null default now()
);
create unique index if not exists g2_clans_name_uq on public.g2_clans (lower(name));
create unique index if not exists g2_clans_tag_uq  on public.g2_clans (tag);

create table if not exists public.g2_clan_members(
  uid       uuid primary key references public.g2_players(uid) on delete cascade,  -- игрок в одном клане
  clan_id   bigint not null references public.g2_clans(id) on delete cascade,
  role      text   not null default 'member' check (role in ('owner', 'coleader', 'veteran', 'member')),
  donated   bigint not null default 0,
  joined_at timestamptz not null default now()
);
create index if not exists g2_clan_members_clan_idx on public.g2_clan_members(clan_id);
create unique index if not exists g2_clan_one_owner_uq on public.g2_clan_members(clan_id) where role = 'owner';

-- ───── RLS: включаем везде, политик нет — к таблицам можно только через функции ─────
do $do$
declare r record;
begin
  for r in select relname from pg_class
            where relnamespace = 'public'::regnamespace and relkind = 'r' and relname like 'g2\_%'
  loop
    execute format('alter table public.%I enable row level security', r.relname);
  end loop;
end $do$;
