-- ============================================================================
-- 19 · ИДЕИ ИГРОКОВ (после 05_auth.sql / 06_admin.sql)
--  · g2_ideas / g2_idea_votes — идеи и голоса (1 голос на игрока за идею)
--  · g2_idea_add     — написать идею (10–300 символов, не больше 5 в сутки)
--  · g2_idea_list    — список: сортировка «Популярные» / «Новые» + мой голос, статус, автор
--  · g2_idea_vote    — поставить / снять голос (за свою идею голосовать нельзя)
--  · g2_idea_delete  — удалить (автор — свою, админ/владелец — любую)
--  · g2_idea_status  — админ/владелец: new | planned | done | rejected
-- Безопасно запускать повторно.
-- ============================================================================

create table if not exists public.g2_ideas (
  id         bigserial primary key,
  author_key text        not null,
  body       text        not null check (char_length(body) between 10 and 300),
  status     text        not null default 'new' check (status in ('new', 'planned', 'done', 'rejected')),
  votes      int         not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists g2_ideas_votes_idx on public.g2_ideas (votes desc, created_at desc);
create index if not exists g2_ideas_author_idx on public.g2_ideas (author_key, created_at desc);

create table if not exists public.g2_idea_votes (
  idea_id    bigint      not null references public.g2_ideas (id) on delete cascade,
  voter_key  text        not null,
  created_at timestamptz not null default now(),
  primary key (idea_id, voter_key)
);
alter table public.g2_ideas      enable row level security;
alter table public.g2_idea_votes enable row level security;

create or replace function public.g2_idea_add(p_token text, p_body text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me  public.g2_players;
  v_b text;
  v_id bigint;
begin
  me := public.g2_auth(p_token);
  v_b := btrim(regexp_replace(coalesce(p_body, ''), '[[:cntrl:]]+', ' ', 'g'));
  if char_length(v_b) < 10 then raise exception 'Идея слишком короткая (минимум 10 символов)'; end if;
  if char_length(v_b) > 300 then raise exception 'Идея слишком длинная (максимум 300 символов)'; end if;
  if (select count(*) from public.g2_ideas
       where author_key = me.key and created_at > now() - interval '24 hours') >= 5 then
    raise exception 'Можно отправить не больше 5 идей в сутки';
  end if;
  if exists (select 1 from public.g2_ideas where author_key = me.key and lower(body) = lower(v_b)) then
    raise exception 'Такая идея уже отправлена';
  end if;
  insert into public.g2_ideas (author_key, body) values (me.key, v_b) returning id into v_id;
  return jsonb_build_object('id', v_id);
end;
$fn$;

create or replace function public.g2_idea_list(p_token text, p_sort text default 'top')
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
begin
  me := public.g2_auth(p_token);
  return coalesce((
    select jsonb_agg(x.j order by x.o1 desc, x.o2 desc)
      from (
        select jsonb_build_object(
                 'id',     i.id,
                 'body',   i.body,
                 'status', i.status,
                 'votes',  i.votes,
                 'mine',   (i.author_key = me.key),
                 'voted',  exists (select 1 from public.g2_idea_votes v where v.idea_id = i.id and v.voter_key = me.key),
                 'nick',   (select u.nick from public.g2_players u where u.key = i.author_key),
                 'ts',     extract(epoch from i.created_at)
               ) as j,
               case when p_sort = 'new' then extract(epoch from i.created_at) else i.votes end as o1,
               extract(epoch from i.created_at) as o2
          from public.g2_ideas i
         order by case when p_sort = 'new' then extract(epoch from i.created_at) else i.votes end desc,
                  i.created_at desc
         limit 60
      ) x
  ), '[]'::jsonb);
end;
$fn$;

create or replace function public.g2_idea_vote(p_token text, p_id bigint)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  it public.g2_ideas;
  v_voted boolean;
begin
  me := public.g2_auth(p_token);
  select * into it from public.g2_ideas where id = p_id for update;
  if not found then raise exception 'Идея не найдена'; end if;
  if it.author_key = me.key then raise exception 'За свою идею голосовать нельзя'; end if;

  if exists (select 1 from public.g2_idea_votes where idea_id = p_id and voter_key = me.key) then
    delete from public.g2_idea_votes where idea_id = p_id and voter_key = me.key;
    v_voted := false;
  else
    insert into public.g2_idea_votes (idea_id, voter_key) values (p_id, me.key);
    v_voted := true;
  end if;
  update public.g2_ideas
     set votes = (select count(*) from public.g2_idea_votes where idea_id = p_id)
   where id = p_id
   returning votes into it.votes;
  return jsonb_build_object('voted', v_voted, 'votes', it.votes);
end;
$fn$;

create or replace function public.g2_idea_delete(p_token text, p_id bigint)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
  it public.g2_ideas;
begin
  me := public.g2_auth(p_token);
  select * into it from public.g2_ideas where id = p_id;
  if not found then raise exception 'Идея не найдена'; end if;
  if it.author_key <> me.key and me.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  delete from public.g2_ideas where id = p_id;
  return jsonb_build_object('ok', true);
end;
$fn$;

create or replace function public.g2_idea_status(p_token text, p_id bigint, p_status text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $fn$
declare
  me public.g2_players;
begin
  me := public.g2_auth(p_token);
  if me.role not in ('owner', 'admin') then raise exception 'Нет доступа'; end if;
  if p_status not in ('new', 'planned', 'done', 'rejected') then raise exception 'Неверный статус'; end if;
  update public.g2_ideas set status = p_status where id = p_id;
  if not found then raise exception 'Идея не найдена'; end if;
  return jsonb_build_object('ok', true);
end;
$fn$;

do $g$
declare f text;
begin
  foreach f in array array[
    'g2_idea_add(text, text)', 'g2_idea_list(text, text)', 'g2_idea_vote(text, bigint)',
    'g2_idea_delete(text, bigint)', 'g2_idea_status(text, bigint, text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to anon, authenticated', f);
  end loop;
end
$g$;
