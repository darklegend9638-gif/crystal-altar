-- ============================================================================
-- 09 · ТРЕЙДЫ: повторки + монеты + алмазы (после 08)
-- Предложение хранится в g2_tr_offers. Обмен не трогает сохранения напрямую: он пишет «накопленные
-- изменения» в g2_tr_adj, а сайт применяет их у игрока (g2_trade_sync) — так нет гонки с g2_save.
-- ============================================================================

-- ───── Помощники (только для внутреннего использования) ─────
create or replace function public.g2_tr_obj(j jsonb) returns jsonb language sql immutable as $fn$
  select case when jsonb_typeof(j) = 'object' then j else '{}'::jsonb end
$fn$;

create or replace function public.g2_tr_num(j jsonb, k text) returns numeric language sql immutable as $fn$
  select case when jsonb_typeof(j -> k) = 'number' then (j ->> k)::numeric else 0 end
$fn$;

create or replace function public.g2_tr_add(a jsonb, d jsonb) returns jsonb language sql immutable as $fn$
  select coalesce(jsonb_object_agg(x.k, public.g2_tr_num(public.g2_tr_obj(a), x.k)
                                      + public.g2_tr_num(public.g2_tr_obj(d), x.k)), '{}'::jsonb)
  from (select jsonb_object_keys(public.g2_tr_obj(a)) as k
        union
        select jsonb_object_keys(public.g2_tr_obj(d))) x
$fn$;

create or replace function public.g2_tr_neg(d jsonb) returns jsonb language sql immutable as $fn$
  select coalesce(jsonb_object_agg(t.k, -public.g2_tr_num(d, t.k)), '{}'::jsonb)
  from jsonb_object_keys(public.g2_tr_obj(d)) as t(k)
$fn$;

-- реальный инвентарь игрока = сохранение + ещё не применённые им изменения
create or replace function public.g2_tr_inv(p_save jsonb, p_ia jsonb) returns jsonb
language plpgsql immutable as $fn$
declare
  f jsonb := public.g2_tr_obj(p_save -> 'found');
  a jsonb := public.g2_tr_obj(p_ia);
  b jsonb := public.g2_tr_obj(p_save -> '_ia');
  res jsonb := '{}'::jsonb; k text; q numeric;
begin
  for k in select jsonb_object_keys(f) union select jsonb_object_keys(a) loop
    q := floor(public.g2_tr_num(f, k)) + public.g2_tr_num(a, k) - public.g2_tr_num(b, k);
    if q <> 0 then res := res || jsonb_build_object(k, q); end if;
  end loop;
  res := res || jsonb_build_object(
    '$coins', floor(public.g2_tr_num(p_save, 'coins')) + public.g2_tr_num(a, '$coins') - public.g2_tr_num(b, '$coins'),
    '$gems',  floor(public.g2_tr_num(p_save, 'gem'))   + public.g2_tr_num(a, '$gems')  - public.g2_tr_num(b, '$gems'));
  return res;
end $fn$;

-- проверка и очистка предложения: {"предмет": кол-во, "$coins": N, "$gems": N}
create or replace function public.g2_tr_clean(p jsonb) returns jsonb
language plpgsql immutable as $fn$
declare res jsonb := '{}'::jsonb; e record; v numeric; n int := 0;
begin
  if jsonb_typeof(p) is distinct from 'object' then raise exception 'Некорректное предложение'; end if;
  for e in select key, value from jsonb_each(p) loop
    if jsonb_typeof(e.value) <> 'number' then raise exception 'Некорректное предложение'; end if;
    v := floor((e.value #>> '{}')::numeric);
    if v < 1 or v > 9000000000000000 then raise exception 'Некорректное предложение'; end if;
    if e.key like '$%' then
      if e.key not in ('$coins', '$gems') then raise exception 'Некорректное предложение'; end if;
    elsif length(e.key) = 0 or length(e.key) > 60 then
      raise exception 'Некорректное предложение';
    end if;
    n := n + 1;
    res := res || jsonb_build_object(e.key, v);
  end loop;
  if n = 0 or n > 40 then raise exception 'Некорректное предложение'; end if;
  return res;
end $fn$;

-- хватает ли у игрока всего нужного (одну копию каждого предмета он оставляет себе)
create or replace function public.g2_tr_has(inv jsonb, need jsonb) returns boolean
language plpgsql immutable as $fn$
declare e record; q numeric;
begin
  for e in select key, value from jsonb_each(need) loop
    q := (e.value #>> '{}')::numeric;
    if e.key like '$%' then
      if public.g2_tr_num(inv, e.key) < q then return false; end if;
    else
      if public.g2_tr_num(inv, e.key) - 1 < q then return false; end if;
    end if;
  end loop;
  return true;
end $fn$;

-- накопленные изменения игрока (создаются из его сохранения; сбрасываются после общего сброса)
create or replace function public.g2_tr_ia(p_uid uuid) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare v jsonb; ep int; row_ep int; sv jsonb;
begin
  select epoch into ep from public.g2_meta where id = 1;
  select ia, epoch into v, row_ep from public.g2_tr_adj where uid = p_uid;
  if found and row_ep = ep then return v; end if;
  select save into sv from public.g2_players where uid = p_uid;
  v := public.g2_tr_obj(sv -> '_ia');
  insert into public.g2_tr_adj(uid, ia, epoch) values (p_uid, v, ep)
  on conflict (uid) do update set ia = excluded.ia, epoch = excluded.epoch;
  return v;
end $fn$;

-- уборка: предложения старше 24 ч и оставшиеся с прошлого общего сброса
create or replace function public.g2_tr_gc() returns void
language plpgsql security definer set search_path = public, extensions as $fn$
declare ep int;
begin
  select epoch into ep from public.g2_meta where id = 1;
  update public.g2_tr_offers set status = 'cancelled', done_at = now()
   where status = 'pending' and epoch <> ep;
  update public.g2_tr_offers set status = 'expired', done_at = now()
   where status = 'pending' and created_at < now() - interval '24 hours';
end $fn$;

-- ───── Функции, которые вызывает сайт ─────

-- что есть у партнёра: повторки, монеты, алмазы
create or replace function public.g2_trade_partner(p_token text, p_nick text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; t public.g2_players; inv jsonb; d jsonb := '{}'::jsonb; e record; q numeric;
begin
  r := public.g2_auth(p_token);
  select * into t from public.g2_players where key = lower(trim(coalesce(p_nick, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if t.uid = r.uid then raise exception 'Нельзя меняться с собой'; end if;
  inv := public.g2_tr_inv(t.save, public.g2_tr_ia(t.uid));
  for e in select key, value from jsonb_each(inv) loop
    q := (e.value #>> '{}')::numeric;
    if e.key not like '$%' and q > 1 then d := d || jsonb_build_object(e.key, q - 1); end if;
  end loop;
  return jsonb_build_object('dupes', d,
    'coins', greatest(0, public.g2_tr_num(inv, '$coins')),
    'gems',  greatest(0, public.g2_tr_num(inv, '$gems')));
end $fn$;

-- отправить предложение
create or replace function public.g2_trade_send(p_token text, p_to text, p_give jsonb, p_want jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; t public.g2_players; g jsonb; w jsonb; cnt int; ep int; oid bigint;
begin
  perform pg_advisory_xact_lock(7003);
  r := public.g2_auth(p_token);
  select * into t from public.g2_players where key = lower(trim(coalesce(p_to, ''))) and not banned;
  if not found then raise exception 'Игрок не найден'; end if;
  if t.uid = r.uid then raise exception 'Нельзя меняться с собой'; end if;
  g := public.g2_tr_clean(p_give);
  w := public.g2_tr_clean(p_want);
  if not public.g2_tr_has(public.g2_tr_inv(r.save, public.g2_tr_ia(r.uid)), g) then
    raise exception 'У вас нет столько предметов или денег';
  end if;
  if not public.g2_tr_has(public.g2_tr_inv(t.save, public.g2_tr_ia(t.uid)), w) then
    raise exception 'У игрока нет столько предметов или денег';
  end if;
  perform public.g2_tr_gc();
  select count(*) into cnt from public.g2_tr_offers where from_uid = r.uid and status = 'pending';
  if cnt >= 10 then raise exception 'Слишком много активных предложений (макс. 10)'; end if;
  select epoch into ep from public.g2_meta where id = 1;
  insert into public.g2_tr_offers(from_uid, to_uid, give, want, epoch)
  values (r.uid, t.uid, g, w, ep) returning id into oid;
  return jsonb_build_object('id', oid);
end $fn$;

-- принять / отклонить (получатель) или отменить (отправитель)
create or replace function public.g2_trade_respond(p_token text, p_id bigint, p_accept boolean) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; p public.g2_players; o public.g2_tr_offers;
        invp jsonb; invq jsonb; ia_q jsonb;
begin
  perform pg_advisory_xact_lock(7003);
  r := public.g2_auth(p_token);
  perform public.g2_tr_gc();
  select * into o from public.g2_tr_offers where id = p_id for update;
  if not found or o.status <> 'pending' then raise exception 'Предложение уже не активно'; end if;

  if r.uid = o.from_uid then                       -- отправитель может только отменить
    if coalesce(p_accept, false) then raise exception 'Нет доступа'; end if;
    update public.g2_tr_offers set status = 'cancelled', done_at = now() where id = o.id;
    return jsonb_build_object('ok', true);
  elsif r.uid <> o.to_uid then
    raise exception 'Нет доступа';
  end if;

  if not coalesce(p_accept, false) then            -- получатель отказывается
    update public.g2_tr_offers set status = 'declined', done_at = now() where id = o.id;
    return jsonb_build_object('ok', true);
  end if;

  select * into p from public.g2_players where uid = o.from_uid;
  if not found or p.banned then raise exception 'Отправитель недоступен'; end if;
  invp := public.g2_tr_inv(p.save, public.g2_tr_ia(p.uid));
  invq := public.g2_tr_inv(r.save, public.g2_tr_ia(r.uid));
  if not public.g2_tr_has(invp, o.give) then
    raise exception 'У отправителя уже нет нужных предметов или денег';
  end if;
  if not public.g2_tr_has(invq, o.want) then
    raise exception 'У вас нет нужных предметов или денег';
  end if;

  -- отправитель: −give +want, получатель: +give −want
  update public.g2_tr_adj
     set ia = public.g2_tr_add(ia, public.g2_tr_add(public.g2_tr_neg(o.give), o.want))
   where uid = p.uid;
  update public.g2_tr_adj
     set ia = public.g2_tr_add(ia, public.g2_tr_add(o.give, public.g2_tr_neg(o.want)))
   where uid = r.uid returning ia into ia_q;
  update public.g2_tr_offers set status = 'done', done_at = now() where id = o.id;
  return jsonb_build_object('iadj', ia_q);
end $fn$;

-- раз в несколько секунд: накопленные изменения + число входящих предложений
create or replace function public.g2_trade_sync(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; inc int;
begin
  r := public.g2_auth(p_token);
  perform public.g2_tr_gc();
  select count(*) into inc from public.g2_tr_offers where to_uid = r.uid and status = 'pending';
  return jsonb_build_object('iadj', public.g2_tr_ia(r.uid), 'inc', inc);
end $fn$;

-- списки: входящие, исходящие, история (с точки зрения игрока)
create or replace function public.g2_trade_list(p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; inn jsonb; outt jsonb; his jsonb;
begin
  r := public.g2_auth(p_token);
  perform public.g2_tr_gc();

  select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'from_nick', f.nick, 'give', o.give, 'want', o.want)
                            order by o.id desc), '[]'::jsonb)
    into inn
    from public.g2_tr_offers o join public.g2_players f on f.uid = o.from_uid
   where o.to_uid = r.uid and o.status = 'pending';

  select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'to_nick', t.nick, 'give', o.give, 'want', o.want)
                            order by o.id desc), '[]'::jsonb)
    into outt
    from public.g2_tr_offers o join public.g2_players t on t.uid = o.to_uid
   where o.from_uid = r.uid and o.status = 'pending';

  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'from_nick', x.nick, 'give', x.give,
                                               'want', x.want, 'status', x.status) order by x.id desc), '[]'::jsonb)
    into his
    from (select o.id, o.status,
                 case when o.from_uid = r.uid then tn.nick else fn.nick end as nick,
                 case when o.from_uid = r.uid then o.give else o.want end as give,
                 case when o.from_uid = r.uid then o.want else o.give end as want
            from public.g2_tr_offers o
            join public.g2_players fn on fn.uid = o.from_uid
            join public.g2_players tn on tn.uid = o.to_uid
           where (o.from_uid = r.uid or o.to_uid = r.uid) and o.status <> 'pending'
           order by o.id desc limit 15) x;

  return jsonb_build_object('incoming', inn, 'outgoing', outt, 'history', his);
end $fn$;
