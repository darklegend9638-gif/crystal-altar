-- ============================================================================
-- 04 · СОХРАНЕНИЕ ПРОГРЕССА С ЗАЩИТОЙ ОТ ДЮПОВ (после 03)
-- Клиент присылает в save поле _v — версию, на которой основан. Если версия не совпала
-- (вторая вкладка/устройство, перевод, админ-правка) — монеты и алмазы берутся с сервера,
-- а «только растущий» прогресс (удача, доход, коллекция…) сливается по максимуму.
-- ============================================================================

-- слияние «только растущих» полей: удача, доход, рекорд, броски, коллекция, питомцы, титулы
create or replace function public.g2_merge_mono(srv jsonb, cli jsonb) returns jsonb
language plpgsql immutable as $fn$
declare o jsonb := coalesce(srv, '{}'::jsonb); fnd jsonb; pts jsonb; tbs jsonb;
begin
  if cli is null or jsonb_typeof(cli) <> 'object' then return o; end if;
  o := jsonb_set(o, '{luck}',  to_jsonb(least(20, greatest(0, greatest(coalesce((srv->>'luck')::numeric, 0), coalesce((cli->>'luck')::numeric, 0))))));
  o := jsonb_set(o, '{inc}',   to_jsonb(least(15, greatest(0, greatest(coalesce((srv->>'inc')::numeric, 0),  coalesce((cli->>'inc')::numeric, 0))))));
  o := jsonb_set(o, '{rolls}', to_jsonb(greatest(coalesce((srv->>'rolls')::numeric, 0),  coalesce((cli->>'rolls')::numeric, 0))));
  o := jsonb_set(o, '{best}',  to_jsonb(greatest(coalesce((srv->>'best')::numeric, -1), coalesce((cli->>'best')::numeric, -1))));

  select coalesce(jsonb_object_agg(k, v), '{}'::jsonb) into fnd from (
    select k, max(v) as v from (
      select e.key as k, case when jsonb_typeof(e.value) = 'number' then (e.value #>> '{}')::numeric else 0 end as v
        from jsonb_each(case when jsonb_typeof(srv->'found') = 'object' then srv->'found' else '{}'::jsonb end) e
      union all
      select e.key, case when jsonb_typeof(e.value) = 'number' then (e.value #>> '{}')::numeric else 0 end
        from jsonb_each(case when jsonb_typeof(cli->'found') = 'object' then cli->'found' else '{}'::jsonb end) e
    ) a group by k) b;
  o := jsonb_set(o, '{found}', fnd);

  select coalesce(jsonb_agg(distinct x.e), '[]'::jsonb) into pts from (
    select jsonb_array_elements_text(case when jsonb_typeof(srv->'pt') = 'array' then srv->'pt' else '[]'::jsonb end) as e
    union
    select jsonb_array_elements_text(case when jsonb_typeof(cli->'pt') = 'array' then cli->'pt' else '[]'::jsonb end)) x;
  o := jsonb_set(o, '{pt}', pts);

  select coalesce(jsonb_agg(distinct x.e), '[]'::jsonb) into tbs from (
    select jsonb_array_elements_text(case when jsonb_typeof(srv->'tb') = 'array' then srv->'tb' else '[]'::jsonb end) as e
    union
    select jsonb_array_elements_text(case when jsonb_typeof(cli->'tb') = 'array' then cli->'tb' else '[]'::jsonb end)) x;
  o := jsonb_set(o, '{tb}', tbs);
  return o;
end $fn$;

create or replace function public.g2_save(p_token text, p_save jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; ep int; base bigint; nv bigint; merged jsonb;
begin
  r := public.g2_auth(p_token);
  select * into r from public.g2_players where key = r.key for update;   -- один писатель за раз
  if r.banned then raise exception 'Аккаунт заблокирован'; end if;

  select epoch into ep from public.g2_meta where id = 1;
  if r.epoch <> ep then                                  -- был общий сброс или админ-правка
    update public.g2_players set epoch = ep where key = r.key;
    return jsonb_build_object('reset', true, 'save', public.g2_save_out(r));
  end if;

  if not public.g2_save_ok(p_save) then raise exception 'Некорректное сохранение'; end if;

  begin base := (p_save->>'_v')::bigint; exception when others then base := null; end;
  if base is distinct from r.ver then                    -- устаревшая вкладка: сливаем прогресс
    merged := public.g2_merge_mono(r.save, p_save);
    update public.g2_players set save = merged, ver = r.ver + 1 where key = r.key returning * into r;
    return jsonb_build_object('reset', true, 'save', public.g2_save_out(r));
  end if;

  p_save := public.g2_clean_save(p_save);              -- убирает _v и ограничивает удачу/доход
  update public.g2_players set save = p_save, ver = r.ver + 1 where key = r.key returning ver into nv;
  return jsonb_build_object('reset', false, 'v', nv);
end $fn$;

-- забрать входящие монеты (сайт опрашивает раз в несколько секунд).
-- Ответ: {amount, from, v} или {stale:true}, если версия клиента устарела.
create or replace function public.g2_claim(p_token text, p_v bigint) returns jsonb
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players; amt numeric; nv bigint;
begin
  r := public.g2_auth(p_token);
  select * into r from public.g2_players where key = r.key for update;
  amt := floor(r.inbox);
  if amt < 1 then return jsonb_build_object('amount', 0, 'v', r.ver); end if;
  if p_v is distinct from r.ver then return jsonb_build_object('stale', true); end if;
  update public.g2_players
     set save = jsonb_set(save, '{coins}', to_jsonb(floor(coalesce((save->>'coins')::numeric, 0)) + amt)),
         inbox = 0, inbox_from = '', ver = ver + 1
   where key = r.key returning ver into nv;
  return jsonb_build_object('amount', amt, 'from', r.inbox_from, 'v', nv);
end $fn$;
