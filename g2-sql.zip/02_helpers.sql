-- ============================================================================
-- 02 · СЛУЖЕБНЫЕ ФУНКЦИИ (после 01). С сайта они недоступны — права закрывает 12_permissions.sql.
-- ============================================================================

-- чистое стартовое сохранение (то же, что FRESH() на сайте)
create or replace function public.g2_fresh() returns jsonb
language sql immutable as $fn$
  select '{"coins":30,"gem":0,"pt":[],"tb":[],"luck":0,"rolls":0,"found":{},"best":-1,"inc":0,"pl":0,"pm":0,"ps":0}'::jsonb
$fn$;

-- допустимое сохранение: объект < 100 КБ, coins — число 0…9e15, gem (если есть) — число 0…9e15
create or replace function public.g2_save_ok(p jsonb) returns boolean
language plpgsql immutable as $fn$
begin
  if p is null or jsonb_typeof(p) <> 'object' or length(p::text) >= 100000 then return false; end if;
  if coalesce(jsonb_typeof(p->'coins'), '') <> 'number' then return false; end if;
  if (p->>'coins')::numeric < 0 or (p->>'coins')::numeric > 9000000000000000 then return false; end if;
  if p->'gem' is not null then
    if jsonb_typeof(p->'gem') <> 'number' then return false; end if;
    if (p->>'gem')::numeric < 0 or (p->>'gem')::numeric > 9000000000000000 then return false; end if;
  end if;
  return true;
end $fn$;

-- чистое сохранение: допустимое — без служебного _v и с удачей/доходом в пределах 0…20 / 0…15, иначе стартовое
-- (используется и при регистрации, и в g2_save — лимиты в одном месте)
create or replace function public.g2_clean_save(p jsonb) returns jsonb
language sql immutable as $fn$
  select case when public.g2_save_ok(p)
    then (p - '_v') || jsonb_build_object(
           'luck', least(20, greatest(0, case when jsonb_typeof(p->'luck') = 'number' then (p->>'luck')::numeric else 0 end)),
           'inc',  least(15, greatest(0, case when jsonb_typeof(p->'inc')  = 'number' then (p->>'inc')::numeric  else 0 end)))
    else public.g2_fresh() end
$fn$;

-- сохранение «на выход» — с текущей версией игрока в поле _v
create or replace function public.g2_save_out(r public.g2_players) returns jsonb
language sql immutable as $fn$
  select jsonb_set(coalesce(r.save, '{}'::jsonb), '{_v}', to_jsonb(r.ver))
$fn$;

create or replace function public.g2_payload(r public.g2_players) returns jsonb
language sql as $fn$
  select jsonb_build_object('token', r.token, 'nick', r.nick, 'avatar', r.avatar,
                            'role', r.role, 'nick_at', r.nick_at, 'save', public.g2_save_out(r))
$fn$;

-- аватар: эмодзи (до 8 символов) или маленькая картинка data:image (до 30 000 знаков)
create or replace function public.g2_av(p text) returns text
language sql immutable as $fn$
  select case
    when p ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$'
      then case when length(p) <= 30000 then p else '😀' end
    else left(coalesce(nullif(p, ''), '😀'), 8)
  end
$fn$;

-- новый случайный токен сессии (64 символа)
create or replace function public.g2_new_token() returns text
language sql volatile as $fn$
  select replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '')
$fn$;

-- вход по токену: возвращает строку игрока (с хешем пароля — поэтому наружу функция закрыта)
create or replace function public.g2_auth(p_token text) returns public.g2_players
language plpgsql security definer set search_path = public, extensions as $fn$
declare r public.g2_players;
begin
  select * into r from public.g2_players
   where token = p_token and p_token is not null and p_token <> '';
  if not found then raise exception 'Сессия недействительна, войдите заново'; end if;
  if r.banned then raise exception 'Аккаунт заблокирован'; end if;
  return r;
end $fn$;
